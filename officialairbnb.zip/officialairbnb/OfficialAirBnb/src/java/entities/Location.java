/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Objects;

/**
 *
 * @author rosa
 */
public class Location {
    private Long house_idhouse;
    private String address;
    private String neighborhood;
    private String transport;

    public Location() {
    }

    public Location(Long house_idhouse, String address, String neighborhood, String transport) {
        this.house_idhouse = house_idhouse;
        this.address = address;
        this.neighborhood = neighborhood;
        this.transport = transport;
    }

    public Long getHouse_idhouse() {
        return house_idhouse;
    }

    public void setHouse_idhouse(Long house_idhouse) {
        this.house_idhouse = house_idhouse;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNeighborhood() {
        return neighborhood;
    }

    public void setNeighborhood(String neighborhood) {
        this.neighborhood = neighborhood;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }

    @Override
    public String toString() {
        return "Location{" + "house_idhouse=" + house_idhouse + ", address=" + address + ", neighborhood=" + neighborhood + ", transport=" + transport + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.house_idhouse);
        hash = 89 * hash + Objects.hashCode(this.address);
        hash = 89 * hash + Objects.hashCode(this.neighborhood);
        hash = 89 * hash + Objects.hashCode(this.transport);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Location other = (Location) obj;
        if (!Objects.equals(this.address, other.address)) {
            return false;
        }
        if (!Objects.equals(this.neighborhood, other.neighborhood)) {
            return false;
        }
        if (!Objects.equals(this.transport, other.transport)) {
            return false;
        }
        if (!Objects.equals(this.house_idhouse, other.house_idhouse)) {
            return false;
        }
        return true;
    }

    public void setTransport(Boolean transport) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
