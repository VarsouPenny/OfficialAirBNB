/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Objects;

/**
 *
 * @author rosa
 */
public class Message {
    private Long message_id;
    private String message;
    private Long sender_iduser;
    private Long receiver_iduser;

    public Message() {
    }

    public Message(Long message_id, String message, Long sender_iduser, Long receiver_iduser) {
        this.message_id = message_id;
        this.message = message;
        this.sender_iduser = sender_iduser;
        this.receiver_iduser = receiver_iduser;
    }

    public Long getMessage_id() {
        return message_id;
    }

    public void setMessage_id(Long message_id) {
        this.message_id = message_id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Long getSender_iduser() {
        return sender_iduser;
    }

    public void setSender_iduser(Long sender_iduser) {
        this.sender_iduser = sender_iduser;
    }

    public Long getReceiver_iduser() {
        return receiver_iduser;
    }

    public void setReceiver_iduser(Long receiver_iduser) {
        this.receiver_iduser = receiver_iduser;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + Objects.hashCode(this.message_id);
        hash = 23 * hash + Objects.hashCode(this.message);
        hash = 23 * hash + Objects.hashCode(this.sender_iduser);
        hash = 23 * hash + Objects.hashCode(this.receiver_iduser);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Message other = (Message) obj;
        if (!Objects.equals(this.message, other.message)) {
            return false;
        }
        if (!Objects.equals(this.message_id, other.message_id)) {
            return false;
        }
        if (!Objects.equals(this.sender_iduser, other.sender_iduser)) {
            return false;
        }
        if (!Objects.equals(this.receiver_iduser, other.receiver_iduser)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Message{" + "message_id=" + message_id + ", message=" + message + ", sender_iduser=" + sender_iduser + ", receiver_iduser=" + receiver_iduser + '}';
    }

    
    
    
}
