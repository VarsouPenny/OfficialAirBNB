/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author rosa
 */
public class Tenantvisitshouse {
    Long user_iduser;
    Long house_idhouse;

    public Tenantvisitshouse() {
    }

    public Tenantvisitshouse(Long user_iduser, Long house_idhouse) {
        this.user_iduser = user_iduser;
        this.house_idhouse = house_idhouse;
    }

    
    public Long getUser_iduser() {
        return user_iduser;
    }

    public void setUser_iduser(Long user_iduser) {
        this.user_iduser = user_iduser;
    }

    public Long getHouse_idhouse() {
        return house_idhouse;
    }

    public void setHouse_idhouse(Long house_idhouse) {
        this.house_idhouse = house_idhouse;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + Objects.hashCode(this.user_iduser);
        hash = 83 * hash + Objects.hashCode(this.house_idhouse);
        return hash;
    }

}
