/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Objects;

/**
 *
 * @author rosa
 */
public class Benefit {
    private Long house_idhouse;
    private Boolean wifi;
    private Boolean aircondition;
    private Boolean heating;
    private Boolean tv;
    private Boolean parking;
    private Boolean elevator;
    private Boolean kitchen;

    public Benefit() {
    }

    public Benefit(Long house_idhouse, Boolean wifi, Boolean aircondition, Boolean heating, Boolean tv, Boolean parking, Boolean elevator, Boolean kitchen) {
        this.house_idhouse = house_idhouse;
        this.wifi = wifi;
        this.aircondition = aircondition;
        this.heating = heating;
        this.tv = tv;
        this.parking = parking;
        this.elevator = elevator;
        this.kitchen = kitchen;
    }

    public Long getHouse_idhouse() {
        return house_idhouse;
    }

    public void setHouse_idhouse(Long house_idhouse) {
        this.house_idhouse = house_idhouse;
    }

    public Boolean getWifi() {
        return wifi;
    }

    public void setWifi(Boolean wifi) {
        this.wifi = wifi;
    }

    public Boolean getAircondition() {
        return aircondition;
    }

    public void setAircondition(Boolean aircondition) {
        this.aircondition = aircondition;
    }

    public Boolean getHeating() {
        return heating;
    }

    public void setHeating(Boolean heating) {
        this.heating = heating;
    }

    public Boolean getTv() {
        return tv;
    }

    public void setTv(Boolean tv) {
        this.tv = tv;
    }

    public Boolean getParking() {
        return parking;
    }

    public void setParking(Boolean parking) {
        this.parking = parking;
    }

    public Boolean getElevator() {
        return elevator;
    }

    public void setElevator(Boolean elevator) {
        this.elevator = elevator;
    }

    public Boolean getKitchen() {
        return kitchen;
    }

    public void setKitchen(Boolean kitchen) {
        this.kitchen = kitchen;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.house_idhouse);
        hash = 37 * hash + Objects.hashCode(this.wifi);
        hash = 37 * hash + Objects.hashCode(this.aircondition);
        hash = 37 * hash + Objects.hashCode(this.heating);
        hash = 37 * hash + Objects.hashCode(this.tv);
        hash = 37 * hash + Objects.hashCode(this.parking);
        hash = 37 * hash + Objects.hashCode(this.elevator);
        hash = 37 * hash + Objects.hashCode(this.kitchen);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Benefit other = (Benefit) obj;
        if (!Objects.equals(this.house_idhouse, other.house_idhouse)) {
            return false;
        }
        if (!Objects.equals(this.wifi, other.wifi)) {
            return false;
        }
        if (!Objects.equals(this.aircondition, other.aircondition)) {
            return false;
        }
        if (!Objects.equals(this.heating, other.heating)) {
            return false;
        }
        if (!Objects.equals(this.tv, other.tv)) {
            return false;
        }
        if (!Objects.equals(this.parking, other.parking)) {
            return false;
        }
        if (!Objects.equals(this.elevator, other.elevator)) {
            return false;
        }
        if (!Objects.equals(this.kitchen, other.kitchen)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Benefit{" + "house_idhouse=" + house_idhouse + ", wifi=" + wifi + ", aircondition=" + aircondition + ", heating=" + heating + ", tv=" + tv + ", parking=" + parking + ", elevator=" + elevator + ", kitchen=" + kitchen + '}';
    }
    
    
    
    
    
}
