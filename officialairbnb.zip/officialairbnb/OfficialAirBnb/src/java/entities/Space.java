/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Objects;

/**
 *
 * @author rosa
 */
public class Space {
    private Long house_idhouse;
    private Long bednum;
    private Long bathnum;
    private Boolean privateroom;
    private Boolean publicroom;
    private Boolean wholehouse;
    private Long bedroomnum;
    private Boolean livingroom;
    private Long dimension;

    public Space() {
    }

    public Space(Long house_idhouse, Long bednum, Long bathnum, Boolean privateroom, Boolean publicroom, Boolean wholehouse, Long bedroomnum, Boolean livingroom, Long dimension) {
        this.house_idhouse = house_idhouse;
        this.bednum = bednum;
        this.bathnum = bathnum;
        this.privateroom = privateroom;
        this.publicroom = publicroom;
        this.wholehouse = wholehouse;
        this.bedroomnum = bedroomnum;
        this.livingroom = livingroom;
        this.dimension = dimension;
    }

    public Long getHouse_idhouse() {
        return house_idhouse;
    }

    public void setHouse_idhouse(Long house_idhouse) {
        this.house_idhouse = house_idhouse;
    }

    public Long getBednum() {
        return bednum;
    }

    public void setBednum(Long bednum) {
        this.bednum = bednum;
    }

    public Long getBathnum() {
        return bathnum;
    }

    public void setBathnum(Long bathnum) {
        this.bathnum = bathnum;
    }

    public Boolean getPrivateroom() {
        return privateroom;
    }

    public void setPrivateroom(Boolean privateroom) {
        this.privateroom = privateroom;
    }

    public Boolean getPublicroom() {
        return publicroom;
    }

    public void setPublicroom(Boolean publicroom) {
        this.publicroom = publicroom;
    }

    public Boolean getWholehouse() {
        return wholehouse;
    }

    public void setWholehouse(Boolean wholehouse) {
        this.wholehouse = wholehouse;
    }

    public Long getBedroomnum() {
        return bedroomnum;
    }

    public void setBedroomnum(Long bedroomnum) {
        this.bedroomnum = bedroomnum;
    }

    public Boolean getLivingroom() {
        return livingroom;
    }

    public void setLivingroom(Boolean livingroom) {
        this.livingroom = livingroom;
    }

    public Long getDimension() {
        return dimension;
    }

    public void setDimension(Long dimension) {
        this.dimension = dimension;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + Objects.hashCode(this.house_idhouse);
        hash = 79 * hash + Objects.hashCode(this.bednum);
        hash = 79 * hash + Objects.hashCode(this.bathnum);
        hash = 79 * hash + Objects.hashCode(this.privateroom);
        hash = 79 * hash + Objects.hashCode(this.publicroom);
        hash = 79 * hash + Objects.hashCode(this.wholehouse);
        hash = 79 * hash + Objects.hashCode(this.bedroomnum);
        hash = 79 * hash + Objects.hashCode(this.livingroom);
        hash = 79 * hash + Objects.hashCode(this.dimension);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Space other = (Space) obj;
        if (!Objects.equals(this.house_idhouse, other.house_idhouse)) {
            return false;
        }
        if (!Objects.equals(this.bednum, other.bednum)) {
            return false;
        }
        if (!Objects.equals(this.bathnum, other.bathnum)) {
            return false;
        }
        if (!Objects.equals(this.privateroom, other.privateroom)) {
            return false;
        }
        if (!Objects.equals(this.publicroom, other.publicroom)) {
            return false;
        }
        if (!Objects.equals(this.wholehouse, other.wholehouse)) {
            return false;
        }
        if (!Objects.equals(this.bedroomnum, other.bedroomnum)) {
            return false;
        }
        if (!Objects.equals(this.livingroom, other.livingroom)) {
            return false;
        }
        if (!Objects.equals(this.dimension, other.dimension)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Space{" + "house_idhouse=" + house_idhouse + ", bednum=" + bednum + ", bathnum=" + bathnum + ", privateroom=" + privateroom + ", publicroom=" + publicroom + ", wholehouse=" + wholehouse + ", bedroomnum=" + bedroomnum + ", livingroom=" + livingroom + ", dimension=" + dimension + '}';
    }
    
    

    
    
}