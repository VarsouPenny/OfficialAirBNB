/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author rosa
 */
public class Tenantreserveshouse {
    Long user_iduser;
    Long house_idhouse;
    Date fromdate;
    Date todate;
    Boolean has_rated;
    Integer rate;

    public Tenantreserveshouse() {
    }

    public Tenantreserveshouse(Long user_iduser, Long house_idhouse, Date fromdate, Date todate, Boolean has_rated, Integer rate) {
        this.user_iduser = user_iduser;
        this.house_idhouse = house_idhouse;
        this.fromdate = fromdate;
        this.todate = todate;
        this.has_rated = has_rated;
        this.rate = rate;
    }

    
    public Long getUser_iduser() {
        return user_iduser;
    }

    public void setUser_iduser(Long user_iduser) {
        this.user_iduser = user_iduser;
    }

    public Long getHouse_idhouse() {
        return house_idhouse;
    }

    public void setHouse_idhouse(Long house_idhouse) {
        this.house_idhouse = house_idhouse;
    }

    public Date getFromdate() {
        return fromdate;
    }

    public void setFromdate(Date fromdate) {
        this.fromdate = fromdate;
    }

    public Date getTodate() {
        return todate;
    }

    public void setTodate(Date todate) {
        this.todate = todate;
    }

    public Boolean getHas_rated() {
        return has_rated;
    }

    public void setHas_rated(Boolean has_rated) {
        this.has_rated = has_rated;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + Objects.hashCode(this.user_iduser);
        hash = 83 * hash + Objects.hashCode(this.house_idhouse);
        hash = 83 * hash + Objects.hashCode(this.fromdate);
        hash = 83 * hash + Objects.hashCode(this.todate);
        hash = 83 * hash + Objects.hashCode(this.has_rated);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Tenantreserveshouse other = (Tenantreserveshouse) obj;
        if (!Objects.equals(this.fromdate, other.fromdate)) {
            return false;
        }
        if (!Objects.equals(this.todate, other.todate)) {
            return false;
        }
        if (!Objects.equals(this.user_iduser, other.user_iduser)) {
            return false;
        }
        if (!Objects.equals(this.house_idhouse, other.house_idhouse)) {
            return false;
        }
        if (!Objects.equals(this.has_rated, other.has_rated)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Tenantreserveshouse{" + "user_iduser=" + user_iduser + ", house_idhouse=" + house_idhouse + ", fromdate=" + fromdate + ", todate=" + todate + ", has_rated=" + has_rated + '}';
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }
    
    
    
}
