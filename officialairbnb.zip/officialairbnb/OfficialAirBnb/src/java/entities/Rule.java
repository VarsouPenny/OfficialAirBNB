/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Objects;

/**
 *
 * @author rosa
 */
public class Rule {
    
    private Long house_idhouse;
    private Boolean smoking;
    private Boolean pets;
    private Boolean party;
    private Long minimumdays;
    private Long extraperperson;

    public Rule() {
    }
    
    

    public Rule(Long house_idhouse, Boolean smoking, Boolean pets, Boolean party, Long minimumdays, Long extraperperson) {
        this.house_idhouse = house_idhouse;
        this.smoking = smoking;
        this.pets = pets;
        this.party = party;
        this.minimumdays = minimumdays;
        this.extraperperson = extraperperson;
    }

    public Long getHouse_idhouse() {
        return house_idhouse;
    }

    public void setHouse_idhouse(Long house_idhouse) {
        this.house_idhouse = house_idhouse;
    }

    public Boolean getSmoking() {
        return smoking;
    }

    public void setSmoking(Boolean smoking) {
        this.smoking = smoking;
    }

    public Boolean getPets() {
        return pets;
    }

    public void setPets(Boolean pets) {
        this.pets = pets;
    }

    public Boolean getParty() {
        return party;
    }

    public void setParty(Boolean party) {
        this.party = party;
    }

    public Long getMinimumdays() {
        return minimumdays;
    }

    public void setMinimumdays(Long minimumdays) {
        this.minimumdays = minimumdays;
    }

    public Long getExtraperperson() {
        return extraperperson;
    }

    public void setExtraperperson(Long extraperperson) {
        this.extraperperson = extraperperson;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 13 * hash + Objects.hashCode(this.house_idhouse);
        hash = 13 * hash + Objects.hashCode(this.smoking);
        hash = 13 * hash + Objects.hashCode(this.pets);
        hash = 13 * hash + Objects.hashCode(this.party);
        hash = 13 * hash + Objects.hashCode(this.minimumdays);
        hash = 13 * hash + Objects.hashCode(this.extraperperson);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Rule other = (Rule) obj;
        if (!Objects.equals(this.house_idhouse, other.house_idhouse)) {
            return false;
        }
        if (!Objects.equals(this.smoking, other.smoking)) {
            return false;
        }
        if (!Objects.equals(this.pets, other.pets)) {
            return false;
        }
        if (!Objects.equals(this.party, other.party)) {
            return false;
        }
        if (!Objects.equals(this.minimumdays, other.minimumdays)) {
            return false;
        }
        if (!Objects.equals(this.extraperperson, other.extraperperson)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Rule{" + "house_idhouse=" + house_idhouse + ", smoking=" + smoking + ", pets=" + pets + ", party=" + party + ", minimumdays=" + minimumdays + ", extraperperson=" + extraperperson + '}';
    }

    

    
    
}
