/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Objects;

/**
 *
 * @author rosa
 */
public class User {
    private Long iduser;
    private String username;
    private String password;
    private String lastname;
    private String firstname;
    private String email;
    private String phonenumber;
    private String photo;
    private Boolean tenant;
    private Boolean housekeeper;
    private Boolean administrator;
    private Boolean activated;

    public User() {
    }

    public User(Long iduser, String username, String password, String lastname, String firstname, String email, String phonenumber, String photo, Boolean tenant, Boolean housekeeper, Boolean administrator, Boolean activated) {
        this.iduser = iduser;
        this.username = username;
        this.password = password;
        this.lastname = lastname;
        this.firstname = firstname;
        this.email = email;
        this.phonenumber = phonenumber;
        this.photo = photo;
        this.tenant = tenant;
        this.housekeeper = housekeeper;
        this.administrator = administrator;
        this.activated = activated;
    }

    public Long getIduser() {
        return iduser;
    }

    public void setIduser(Long iduser) {
        this.iduser = iduser;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Boolean getTenant() {
        return tenant;
    }

    public void setTenant(Boolean tenant) {
        this.tenant = tenant;
    }

    public Boolean getHousekeeper() {
        return housekeeper;
    }

    public void setHousekeeper(Boolean housekeeper) {
        this.housekeeper = housekeeper;
    }

    public Boolean getAdministrator() {
        return administrator;
    }

    public void setAdministrator(Boolean administrator) {
        this.administrator = administrator;
    }

    @Override
    public String toString() {
        return "User{" + "iduser=" + iduser + ", username=" + username + ", password=" + password + ", lastname=" + lastname + ", firstname=" + firstname + ", email=" + email + ", phonenumber=" + phonenumber + ", photo=" + photo + ", tenant=" + tenant + ", housekeeper=" + housekeeper + ", administrator=" + administrator + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 73 * hash + Objects.hashCode(this.iduser);
        hash = 73 * hash + Objects.hashCode(this.username);
        hash = 73 * hash + Objects.hashCode(this.password);
        hash = 73 * hash + Objects.hashCode(this.lastname);
        hash = 73 * hash + Objects.hashCode(this.firstname);
        hash = 73 * hash + Objects.hashCode(this.email);
        hash = 73 * hash + Objects.hashCode(this.phonenumber);
        hash = 73 * hash + Objects.hashCode(this.photo);
        hash = 73 * hash + Objects.hashCode(this.tenant);
        hash = 73 * hash + Objects.hashCode(this.housekeeper);
        hash = 73 * hash + Objects.hashCode(this.administrator);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        if (!Objects.equals(this.lastname, other.lastname)) {
            return false;
        }
        if (!Objects.equals(this.firstname, other.firstname)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.phonenumber, other.phonenumber)) {
            return false;
        }
        if (!Objects.equals(this.photo, other.photo)) {
            return false;
        }
        if (!Objects.equals(this.iduser, other.iduser)) {
            return false;
        }
        if (!Objects.equals(this.tenant, other.tenant)) {
            return false;
        }
        if (!Objects.equals(this.housekeeper, other.housekeeper)) {
            return false;
        }
        if (!Objects.equals(this.administrator, other.administrator)) {
            return false;
        }
        return true;
    }

    public Boolean getActivated() {
        return activated;
    }

    public void setActivated(Boolean activated) {
        this.activated = activated;
    }

    
    
}
