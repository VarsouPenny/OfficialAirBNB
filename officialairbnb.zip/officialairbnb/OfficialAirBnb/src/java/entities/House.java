/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;
import java.util.Date;
import java.util.Objects; 

/**
 *
 * @author rosa
 */
public class House {
    private Long idhouse;
    private Long priceperday;
    private Long people;
    private Long floor;
    private String fromdate;
    private String todate;
    private String country;
    private String city;
    private Long stars;
    private String description;
    private Long housekeeper_id;
    private Long numofcritisism;
    private String photo;
    
    private Space space;
    private Location location;
    private Rule rule;
    private Benefit benefit;
    
    public House() {
    }
    
    public House(Long idhouse, Long priceperday, Long people, Long floor, String fromdate, String todate, String country, String city, Long stars, String description, Long housekeeper_id, Long numofcritisism, String photo) {
        this.idhouse = idhouse;
        this.priceperday = priceperday;
        this.people = people;
        this.floor = floor;
        this.fromdate = fromdate;
        this.todate = todate;
        this.country = country;
        this.city = city;
        this.stars = stars;
        this.description = description;
        this.housekeeper_id = housekeeper_id;
        this.numofcritisism = numofcritisism;
        this.photo = photo;
    }

    public Long getIdhouse() {
        return idhouse;
    }

    public void setIdhouse(Long idhouse) {
        this.idhouse = idhouse;
    }

    public Long getPriceperday() {
        return priceperday;
    }

    public void setPriceperday(Long priceperday) {
        this.priceperday = priceperday;
    }

    public Long getPeople() {
        return people;
    }

    public void setPeople(Long people) {
        this.people = people;
    }

    public Long getFloor() {
        return floor;
    }

    public void setFloor(Long floor) {
        this.floor = floor;
    }

    public String getFromdate() {
        return fromdate;
    }

    public void setFromdate(String fromdate) {
        this.fromdate = fromdate;
    }

    public String getTodate() {
        return todate;
    }

    public void setTodate(String todate) {
        this.todate = todate;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Long getStars() {
        return stars;
    }

    public void setStars(Long stars) {
        this.stars = stars;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getHousekeeper_id() {
        return housekeeper_id;
    }

    public void setHousekeeper_id(Long housekeeper_id) {
        this.housekeeper_id = housekeeper_id;
    }

    public Long getNumofcritisism() {
        return numofcritisism;
    }

    public void setNumofcritisism(Long numofcritisism) {
        this.numofcritisism = numofcritisism;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.idhouse);
        hash = 53 * hash + Objects.hashCode(this.priceperday);
        hash = 53 * hash + Objects.hashCode(this.people);
        hash = 53 * hash + Objects.hashCode(this.floor);
        hash = 53 * hash + Objects.hashCode(this.fromdate);
        hash = 53 * hash + Objects.hashCode(this.todate);
        hash = 53 * hash + Objects.hashCode(this.country);
        hash = 53 * hash + Objects.hashCode(this.city);
        hash = 53 * hash + Objects.hashCode(this.stars);
        hash = 53 * hash + Objects.hashCode(this.description);
        hash = 53 * hash + Objects.hashCode(this.housekeeper_id);
        hash = 53 * hash + Objects.hashCode(this.numofcritisism);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final House other = (House) obj;
        if (!Objects.equals(this.fromdate, other.fromdate)) {
            return false;
        }
        if (!Objects.equals(this.todate, other.todate)) {
            return false;
        }
        if (!Objects.equals(this.country, other.country)) {
            return false;
        }
        if (!Objects.equals(this.city, other.city)) {
            return false;
        }
        if (!Objects.equals(this.description, other.description)) {
            return false;
        }
        if (!Objects.equals(this.idhouse, other.idhouse)) {
            return false;
        }
        if (!Objects.equals(this.priceperday, other.priceperday)) {
            return false;
        }
        if (!Objects.equals(this.people, other.people)) {
            return false;
        }
        if (!Objects.equals(this.floor, other.floor)) {
            return false;
        }
        if (!Objects.equals(this.stars, other.stars)) {
            return false;
        }
        if (!Objects.equals(this.housekeeper_id, other.housekeeper_id)) {
            return false;
        }
        if (!Objects.equals(this.numofcritisism, other.numofcritisism)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "House{" + "idhouse=" + idhouse + ", priceperday=" + priceperday + ", people=" + people + ", floor=" + floor + ", fromdate=" + fromdate + ", todate=" + todate + ", country=" + country + ", city=" + city + ", stars=" + stars + ", description=" + description + ", housekeeper_id=" + housekeeper_id + ", numofcritisism=" + numofcritisism + '}';
    }

    public Space getSpace() {
        return space;
    }

    public void setSpace(Space space) {
        this.space = space;
    }
    
    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }
    
    public Rule getRule() {
        return rule;
    }

    public void setRule(Rule rule) {
        this.rule = rule;
    }
    
    public Benefit getBenefit() {
        return benefit;
    }

    public void setBenefit(Benefit benefit) {
        this.benefit = benefit;
    }

    public void setFromdate(Date fromdate) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setTodate(Date todate) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}


   