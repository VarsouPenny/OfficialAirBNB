/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datastructures;

import entities.User;

/**
 *
 * @author rosa
 */
public class Node {
    public UserNode user;
    public Float value;

    public Node(UserNode user, Float value) {
        this.user = user;
        this.value = value;
    }
}
