/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datastructures;

import entities.House;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rosa
 */
public class HouseNode implements Comparable<HouseNode>{
    public House house;
    public float score = 0;
    public boolean may_be_recommended = true;
    public List<Node> nodes = new ArrayList<>();

    public HouseNode(House house) {
        this.house = house;
    }

    @Override
    public int compareTo(HouseNode o) {
        if (this.score > o.score) {
            return -1;
        } else if (this.score == o.score) {
            return 0;
        } else {
            return +1;
        }
    }
}
