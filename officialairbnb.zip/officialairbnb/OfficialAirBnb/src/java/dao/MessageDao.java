/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Message;
import entities.MessageList;
import entities.User;
import java.util.List;
/**
 *
 * @author rosa
 */
public interface MessageDao {
    public List<Message> select(ConnectionManager manager);
    
    public Message select(ConnectionManager manager, Long id);
    
    
    public List<Message> select(ConnectionManager manager, String username);
    
    public MessageList select_inbox(ConnectionManager manager, String username);
    
    public MessageList select_outbox(ConnectionManager manager, String username);
    
    public void insert(ConnectionManager manager, Message message);
    
    public boolean update(ConnectionManager manager, Message message);
    
    public boolean delete(ConnectionManager manager, Long key);
    
}
