/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.House;
import entities.HouseList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author rosa
 */
public class HouseDaoImpl implements HouseDao {

    class Queries {

        static final String SELECT_ALL = "SELECT * FROM house";
        static final String SELECT_PROTOTYPE = "SELECT * FROM house inner join location on location.house_idhouse=house.idhouse inner join space on space.house_idhouse=house.idhouse inner join benefit on benefit.house_idhouse=house.idhouse inner join rule on rule.house_idhouse=house.idhouse where fromdate > ? and todate < ?";
        static final String SELECT_BY_PK = "SELECT * FROM house WHERE idhouse = ?";
        static final String SELECT_BY_USERNAME = "SELECT * FROM house WHERE housekeeper_id = (select iduser from user where username = ?)";
        static final String UPDATE = "UPDATE house SET priceperday = ?, people = ?, floor = ?, fromdate = ?, todate = ?, country = ?, city = ?, description = ?, photo = ? WHERE idhouse = ?";
        static final String RATE = "UPDATE house SET numofcritisism = numofcritisism + 1, stars=stars + ? WHERE idhouse = ?";
        static final String INSERT = "INSERT INTO house(priceperday, people, floor, fromdate, todate, country, city, stars, description, housekeeper_id, numofcritisism, photo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        static final String DELETE_BY_PK = "DELETE FROM house WHERE idhouse = ?";
    }

    private static House map(ResultSet row_ptr) throws SQLException {
        House house = new House();
        house.setIdhouse(row_ptr.getLong("idhouse"));
        house.setPriceperday(row_ptr.getLong("priceperday"));
        house.setPeople(row_ptr.getLong("people"));
        house.setFloor(row_ptr.getLong("floor"));
        house.setFromdate(row_ptr.getString("fromdate"));
        house.setTodate(row_ptr.getString("todate"));
        house.setCountry(row_ptr.getString("country"));
        house.setCity(row_ptr.getString("city"));
        Long s = row_ptr.getLong("stars");
        Long n = row_ptr.getLong("numofcritisism");
        
        Long stars ;
        if (n == 0) {
            stars = 0L;
        } else {
            stars = s/n;
        }
        
        house.setStars(stars);
        house.setDescription(row_ptr.getString("description"));
        house.setHousekeeper_id(row_ptr.getLong("housekeeper_id"));
        house.setNumofcritisism(row_ptr.getLong("numofcritisism"));
        house.setPhoto(row_ptr.getString("photo"));
        return house;
    }

    private static Object[] reverse_map(House house) {
        Object[] values = new Object[]{
            house.getPriceperday(),
            house.getPeople(),
            house.getFloor(),
            house.getFromdate(),
            house.getTodate(),
            house.getCountry(),
            house.getCity(),
            house.getStars(),
            house.getDescription(),
            house.getHousekeeper_id(),
            house.getNumofcritisism(),
            house.getPhoto()
        };
        return values;
    }

    private static Object[] reverse_map_update(House house) {
        Object[] values = new Object[]{
            house.getPriceperday(),
            house.getPeople(),
            house.getFloor(),
            house.getFromdate(),
            house.getTodate(),
            house.getCountry(),
            house.getCity(),
            house.getDescription(),
            house.getPhoto()
        };
        return values;
    }

    @Override
    public List<House> select(ConnectionManager manager) {
        List<House> houses = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                House dbhouse = map(resultSet);
                houses.add(dbhouse);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return houses;
    }

    @Override
    public House select(ConnectionManager manager, Long id) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_BY_PK, id);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    House dbhouse = map(resultSet);
                    return dbhouse;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return null;
    }
    
    
    @Override
    public HouseList selectForHousekeeper(ConnectionManager manager, String username) {
        HouseList houses = new HouseList();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_BY_USERNAME, username);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                House dbhouse = map(resultSet);
                houses.add(dbhouse);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return houses;
    }
    
    public HouseList selectForTenant(ConnectionManager manager, String username) {
        HouseList houses = new HouseList();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_BY_USERNAME, username);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                House dbhouse = map(resultSet);
                houses.add(dbhouse);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return houses;
    }
    

//    @Override
//    public User select(ConnectionManager manager, String username) {
//        try (PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_BY_USERNAME, username);) {
//
//            try (ResultSet resultSet = statement.executeQuery();) {
//                while (resultSet.next()) {
//                    User dbuser = map(resultSet);
//                    return dbuser;
//                }
//            }
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        }
//
//        return null;
//    }
    @Override
    public void insert(ConnectionManager manager, House house) {
        Object[] values = reverse_map(house);

        try (PreparedStatement statement = manager.prepareStatementForInsert(Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                house.setIdhouse(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean update(ConnectionManager manager, House house) {
        Object[] values = reverse_map_update(house);

        try (PreparedStatement statement = manager.prepareStatementForUpdate(Queries.UPDATE, values);) {
            int output = statement.executeUpdate();
            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(ConnectionManager manager, Long key) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(Queries.DELETE_BY_PK, key);) {
            int output = statement.executeUpdate();

            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public HouseList search(ConnectionManager manager, Date fromdate, Date todate, String form_text, Long people, Boolean entirehome, Boolean privateroom, Boolean sharedroom, Long priceperday, Long bedroomnum, Long bathroomnum, Long bednum, Boolean livingroom, Boolean kitchen, Boolean smoking, Boolean pets, Boolean party, Boolean parking, Boolean elevator, Boolean wifi, Boolean aircondition, Boolean heating, Boolean tv, Long floor, Long dimension, String form_address, Boolean transportation) {
        HouseList houses = new HouseList();
        StringBuilder dynamicSQL = new StringBuilder();

        dynamicSQL.append(Queries.SELECT_PROTOTYPE);

        if (form_text != null && form_text.trim().length() > 0) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" neighborhood like '%").append(form_text).append("%'");
            dynamicSQL.append(" or country like '%").append(form_text).append("%'");
            dynamicSQL.append(" or city like '%").append(form_text).append("%'");
            dynamicSQL.append(")");
        }
        
        if (people != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" people >= ").append(people);
            dynamicSQL.append(")");
        }
        
        if (entirehome != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" wholehouse = true");
            dynamicSQL.append(")");
        }
        
        if (privateroom != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" privateroom = true");
            dynamicSQL.append(")");
        }
        
        if (sharedroom != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" publicroom = true");
            dynamicSQL.append(")");
        }
        
        if (priceperday != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" priceperday <= ").append(priceperday);
            dynamicSQL.append(")");
        }
        
        if (bedroomnum != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" bedroomnum = ").append(bedroomnum);
            dynamicSQL.append(")");
        }
        
        if (bathroomnum != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" bathnum = ").append(bathroomnum);
            dynamicSQL.append(")");
        }
        
        if (bednum != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" bednum = ").append(bednum);
            dynamicSQL.append(")");
        }
        
        if (livingroom != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" livingroom = true");
            dynamicSQL.append(")");
        }
        
        if (kitchen != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" kitchen = true");
            dynamicSQL.append(")");
        }
        
        if (smoking != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" smoking = true");
            dynamicSQL.append(")");
        }
        
        if (pets != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" pets = true");
            dynamicSQL.append(")");
        }
        
        if (party != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" party = true");
            dynamicSQL.append(")");
        }
        
        if (parking != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" parking = true");
            dynamicSQL.append(")");
        }
        
        if (elevator != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" elevator = true");
            dynamicSQL.append(")");
        }
        
        if (wifi != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" wifi = true");
            dynamicSQL.append(")");
        }
        
        if (aircondition != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" aircondition = true");
            dynamicSQL.append(")");
        }
        
        if (heating != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" heating = true");
            dynamicSQL.append(")");
        }
        
        if (tv != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" tv = true");
            dynamicSQL.append(")");
        }
        
        if (floor != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" floor = ").append(floor);
            dynamicSQL.append(")");
        }
        
        if (transportation != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" transport = true");
            dynamicSQL.append(")");
        }
        
        if (dimension != null) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" dimension >= ").append(dimension);
            dynamicSQL.append(")");
        }
        
        if (form_address != null && form_address.trim().length() > 0) {
            dynamicSQL.append(" and (");
            dynamicSQL.append(" address like '%").append(form_address).append("%'");
            dynamicSQL.append(")");
        }
        
        String finalquery = dynamicSQL.toString();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(finalquery, fromdate, todate);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                House dbhouse = map(resultSet);
                houses.add(dbhouse);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return houses;
    }
    
    public int rate(ConnectionManager manager, Long idhouse, int rate) {
        Object[] values = new Object[] {
            rate,
            idhouse
        };

        try (PreparedStatement statement = manager.prepareStatementForUpdate(Queries.RATE, values);) {
            int output = statement.executeUpdate();
            return output;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return -1;
    }
}
