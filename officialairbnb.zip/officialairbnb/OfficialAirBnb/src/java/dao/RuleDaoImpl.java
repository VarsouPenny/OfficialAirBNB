/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Rule;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author rosa
 */
public class RuleDaoImpl implements RuleDao{
    
    class Queries {

        static final String SELECT_ALL = "SELECT * FROM rule";
        static final String SELECT_BY_PK = "SELECT * FROM rule WHERE house_idhouse = ?";
        //static final String SELECT_BY_USERNAME = "SELECT * FROM user WHERE username = ?";
        static final String UPDATE = "UPDATE rule SET smoking= ?, pets = ?, party = ?, parking = ?, minimumdays = ?, extraperperson = ? WHERE house_idhouse= ?";
        static final String INSERT = "INSERT INTO rule(house_idhouse, smoking, pets, party, parking, minimumdays, extraperperson) VALUES (?,?,?,?,?,?,?)";
        static final String DELETE_BY_PK = "DELETE FROM rule WHERE house_idhouse = ?";
    }

    private static Rule map(ResultSet row_ptr) throws SQLException {
        Rule rule = new Rule();
        rule.setHouse_idhouse(row_ptr.getLong("house_idhouse"));
        rule.setSmoking(row_ptr.getBoolean("smoking"));
        rule.setPets(row_ptr.getBoolean("pets"));
        rule.setParty(row_ptr.getBoolean("party"));        
        rule.setMinimumdays(row_ptr.getLong("minimumdays"));
        rule.setExtraperperson(row_ptr.getLong("extraperperson"));
        return rule;
    }

    private static Object[] reverse_map(Rule rule) {
        Object[] values = new Object[]{
            rule.getHouse_idhouse(),
            rule.getSmoking(),
            rule.getPets(),
            rule.getParty(),
            rule.getMinimumdays(),
            rule.getExtraperperson()
        };
        return values;
    }

    private static Object[] reverse_map_update(Rule rule) {
        Object[] values = new Object[]{
            rule.getSmoking(),
            rule.getPets(),
            rule.getParty(),
            rule.getMinimumdays(),
            rule.getExtraperperson()
        };
        return values;
    }

    @Override
    public List<Rule> select(ConnectionManager manager) {
        List<Rule> rules = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(RuleDaoImpl.Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                Rule dbrule = map(resultSet);
                rules.add(dbrule);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return rules;
    }

    @Override
    public Rule select(ConnectionManager manager, Long id) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(RuleDaoImpl.Queries.SELECT_BY_PK, id);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    Rule dbrule = map(resultSet);
                    return dbrule;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return null;
    }

//    @Override
//    public Location select(ConnectionManager manager, String username) {
//        try (PreparedStatement statement = manager.prepareStatementForSelect(UserDaoImpl.Queries.SELECT_BY_USERNAME, username);) {
//
//            try (ResultSet resultSet = statement.executeQuery();) {
//                while (resultSet.next()) {
//                    Location dblocation = map(resultSet);
//                    return dblocation;
//                }
//            }
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        }
//
//        return null;
//    }

    @Override
    public void insert(ConnectionManager manager, Rule rule) {
        Object[] values = reverse_map(rule);

        try (PreparedStatement statement = manager.prepareStatementForInsert(RuleDaoImpl.Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                rule.setHouse_idhouse(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean update(ConnectionManager manager, Rule rule) {
        Object[] values = reverse_map_update(rule);

        try (PreparedStatement statement = manager.prepareStatementForUpdate(RuleDaoImpl.Queries.UPDATE, values);) {
            int output = statement.executeUpdate();
            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(ConnectionManager manager, Long key) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(RuleDaoImpl.Queries.DELETE_BY_PK, key);) {
            int output = statement.executeUpdate();

            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }
    
}
