/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;


import dbfactory.ConnectionManager;
import entities.Location;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author rosa
 */

public class LocationDaoImpl implements LocationDao{

    class Queries {

        static final String SELECT_ALL = "SELECT * FROM location";
        static final String SELECT_BY_PK = "SELECT * FROM location WHERE house_idhouse = ?";
        //static final String SELECT_BY_USERNAME = "SELECT * FROM user WHERE username = ?";
        static final String UPDATE = "UPDATE location SET address= ?, neighborhood = ?, transport = ? WHERE house_idhouse= ?";
        static final String INSERT = "INSERT INTO location(house_idhouse, address, neighborhood, transport) VALUES (?,?,?,?)";
        static final String DELETE_BY_PK = "DELETE FROM location WHERE house_idhouse = ?";
    }

    private static Location map(ResultSet row_ptr) throws SQLException {
        Location location = new Location();
        location.setHouse_idhouse(row_ptr.getLong("house_idhouse"));
        location.setAddress(row_ptr.getString("address"));
        location.setNeighborhood(row_ptr.getString("neighborhood"));
        location.setTransport(row_ptr.getString("transport"));
        return location;
    }

    private static Object[] reverse_map(Location location) {
        Object[] values = new Object[]{
            location.getHouse_idhouse(),
            location.getAddress(),
            location.getNeighborhood(),
            location.getTransport(),
        };
        return values;
    }

    private static Object[] reverse_map_update(Location location) {
        Object[] values = new Object[]{
            location.getAddress(),
            location.getNeighborhood(),
            location.getTransport()
        };
        return values;
    }

    @Override
    public List<Location> select(ConnectionManager manager) {
        List<Location> locations = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(LocationDaoImpl.Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                Location dblocation = map(resultSet);
                locations.add(dblocation);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return locations;
    }

    @Override
    public Location select(ConnectionManager manager, Long id) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(LocationDaoImpl.Queries.SELECT_BY_PK, id);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    Location dblocation = map(resultSet);
                    return dblocation;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return null;
    }

//    @Override
//    public Location select(ConnectionManager manager, String username) {
//        try (PreparedStatement statement = manager.prepareStatementForSelect(UserDaoImpl.Queries.SELECT_BY_USERNAME, username);) {
//
//            try (ResultSet resultSet = statement.executeQuery();) {
//                while (resultSet.next()) {
//                    Location dblocation = map(resultSet);
//                    return dblocation;
//                }
//            }
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        }
//
//        return null;
//    }

    @Override
    public void insert(ConnectionManager manager, Location location) {
        Object[] values = reverse_map(location);

        try (PreparedStatement statement = manager.prepareStatementForInsert(LocationDaoImpl.Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                location.setHouse_idhouse(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean update(ConnectionManager manager, Location location) {
        Object[] values = reverse_map_update(location);

        try (PreparedStatement statement = manager.prepareStatementForUpdate(LocationDaoImpl.Queries.UPDATE, values);) {
            int output = statement.executeUpdate();
            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(ConnectionManager manager, Long key) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(LocationDaoImpl.Queries.DELETE_BY_PK, key);) {
            int output = statement.executeUpdate();

            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }
    
}
