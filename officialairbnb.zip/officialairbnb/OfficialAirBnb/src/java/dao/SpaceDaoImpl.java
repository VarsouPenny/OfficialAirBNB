/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Space;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rosa
 */
public class SpaceDaoImpl implements SpaceDao{
    class Queries {

        static final String SELECT_ALL = "SELECT * FROM space";
        static final String SELECT_BY_PK = "SELECT * FROM space WHERE house_idhouse = ?";
        //static final String SELECT_BY_USERNAME = "SELECT * FROM user WHERE username = ?";
        static final String UPDATE = "UPDATE space SET bednum= ?, bathnum = ?, privateroom = ?, publicroom = ?, wholehouse = ?, bedroomnum = ?, livingroom = ?, dimension = ? WHERE house_idhouse= ?";
        static final String INSERT = "INSERT INTO space(house_idhouse, bednum, bathnum, privateroom, publicroom, wholehouse, bedroomnum, livingroom, dimension) VALUES (?,?,?,?,?,?,?,?,?)";
        static final String DELETE_BY_PK = "DELETE FROM space WHERE house_idhouse = ?";
    }

    private static Space map(ResultSet row_ptr) throws SQLException {
        Space space = new Space();
        space.setHouse_idhouse(row_ptr.getLong("house_idhouse"));
        space.setBednum(row_ptr.getLong("bednum"));
        space.setBathnum(row_ptr.getLong("bathnum"));
        space.setPrivateroom(row_ptr.getBoolean("privateroom"));
        space.setPublicroom(row_ptr.getBoolean("publicroom"));
        space.setWholehouse(row_ptr.getBoolean("wholehouse"));
        space.setBedroomnum(row_ptr.getLong("bedroomnum"));
        space.setLivingroom(row_ptr.getBoolean("livingroom"));
        space.setDimension(row_ptr.getLong("dimension"));
        return space;
    }

    private static Object[] reverse_map(Space space) {
        Object[] values = new Object[]{
            space.getHouse_idhouse(),
            space.getBednum(),
            space.getBathnum(),
            space.getPrivateroom(),
            space.getPublicroom(),
            space.getWholehouse(),
            space.getBedroomnum(),
            space.getLivingroom(),
            space.getDimension(),
        };
        return values;
    }

    private static Object[] reverse_map_update(Space space) {
        Object[] values = new Object[]{
            space.getBednum(),
            space.getBathnum(),
            space.getPrivateroom(),
            space.getPublicroom(),
            space.getWholehouse(),
            space.getBedroomnum(),
            space.getLivingroom(),
            space.getDimension(),
        };
        return values;
    }

    @Override
    public List<Space> select(ConnectionManager manager) {
        List<Space> spaces = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(SpaceDaoImpl.Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                Space dbspace = map(resultSet);
                spaces.add(dbspace);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return spaces;
    }

    @Override
    public Space select(ConnectionManager manager, Long id) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(SpaceDaoImpl.Queries.SELECT_BY_PK, id);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    Space dbspace = map(resultSet);
                    return dbspace;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return null;
    }

//    @Override
//    public Location select(ConnectionManager manager, String username) {
//        try (PreparedStatement statement = manager.prepareStatementForSelect(UserDaoImpl.Queries.SELECT_BY_USERNAME, username);) {
//
//            try (ResultSet resultSet = statement.executeQuery();) {
//                while (resultSet.next()) {
//                    Location dblocation = map(resultSet);
//                    return dblocation;
//                }
//            }
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        }
//
//        return null;
//    }

    @Override
    public void insert(ConnectionManager manager, Space space) {
        Object[] values = reverse_map(space);

        try (PreparedStatement statement = manager.prepareStatementForInsert(SpaceDaoImpl.Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                space.setHouse_idhouse(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean update(ConnectionManager manager, Space space) {
        Object[] values = reverse_map_update(space);

        try (PreparedStatement statement = manager.prepareStatementForUpdate(SpaceDaoImpl.Queries.UPDATE, values);) {
            int output = statement.executeUpdate();
            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(ConnectionManager manager, Long key) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(SpaceDaoImpl.Queries.DELETE_BY_PK, key);) {
            int output = statement.executeUpdate();

            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }
    
    
}
