/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Tenantreserveshouse;
import entities.Tenantvisitshouse;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rosa
 */
public class TenantVisitshouseDaoImpl implements TenantVisitshouseDao {

    class Queries {
        static final String SELECT_ALL = "SELECT * FROM tenant_visits_house";
        static final String INSERT = "INSERT INTO tenant_visits_house(user_iduser, house_idhouse) VALUES (?,?)";
    }

    private static Tenantvisitshouse map(ResultSet row_ptr) throws SQLException {
        Tenantvisitshouse t = new Tenantvisitshouse();
        t.setUser_iduser(row_ptr.getLong("user_iduser"));
        t.setHouse_idhouse(row_ptr.getLong("house_idhouse"));
        return t;
    }

    private static Object[] reverse_map(Tenantvisitshouse t) {
        Object[] values = new Object[]{
            t.getUser_iduser(),
            t.getHouse_idhouse()
        };
        return values;
    }

    @Override
    public List<Tenantvisitshouse> select(ConnectionManager manager) {
        List<Tenantvisitshouse> t = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(TenantVisitshouseDaoImpl.Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                Tenantvisitshouse dbtenant = map(resultSet);
                t.add(dbtenant);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return t;
    }

    public void insert(ConnectionManager manager, Tenantvisitshouse tenantvisitshouse) {
        Object[] values = reverse_map(tenantvisitshouse);

        try (PreparedStatement statement = manager.prepareStatementForInsert(TenantVisitshouseDaoImpl.Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                tenantvisitshouse.setHouse_idhouse(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
