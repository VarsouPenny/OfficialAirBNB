/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Benefit;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rosa
 */
public class BenefitDaoImpl implements BenefitDao{
    
    class Queries {

        static final String SELECT_ALL = "SELECT * FROM benefit";
        static final String SELECT_BY_PK = "SELECT * FROM benefit WHERE house_idhouse = ?";
        //static final String SELECT_BY_USERNAME = "SELECT * FROM user WHERE username = ?";
        static final String UPDATE = "UPDATE benefit SET wifi= ?, aircondition = ?, heating = ?, tv = ?, parking = ?, elevator = ?, kitchen = ? WHERE house_idhouse= ?";
        static final String INSERT = "INSERT INTO benefit(house_idhouse, wifi, aircondition, heating, tv, parking, elevator, kitchen) VALUES (?,?,?,?,?,?,?,?)";
        static final String DELETE_BY_PK = "DELETE FROM benefit WHERE house_idhouse = ?";
    }

    private static Benefit map(ResultSet row_ptr) throws SQLException {
        Benefit benefit = new Benefit();
        benefit.setHouse_idhouse(row_ptr.getLong("house_idhouse"));
        benefit.setWifi(row_ptr.getBoolean("wifi"));
        benefit.setAircondition(row_ptr.getBoolean("aircondition"));
        benefit.setHeating(row_ptr.getBoolean("heating"));
        benefit.setTv(row_ptr.getBoolean("tv"));
        benefit.setParking(row_ptr.getBoolean("parking"));
        benefit.setElevator(row_ptr.getBoolean("elevator"));
        benefit.setKitchen(row_ptr.getBoolean("kitchen"));
        return benefit;
    }

    private static Object[] reverse_map(Benefit benefit) {
        Object[] values = new Object[]{
            benefit.getHouse_idhouse(),
            benefit.getWifi(),
            benefit.getAircondition(),
            benefit.getHeating(),
            benefit.getTv(),
            benefit.getParking(),
            benefit.getElevator(),
            benefit.getKitchen(),
        };
        return values;
    }

    private static Object[] reverse_map_update(Benefit benefit) {
        Object[] values = new Object[]{
            benefit.getWifi(),
            benefit.getAircondition(),
            benefit.getHeating(),
            benefit.getTv(),
            benefit.getParking(),
            benefit.getElevator(),
            benefit.getKitchen()
        };
        return values;
    }

    @Override
    public List<Benefit> select(ConnectionManager manager) {
        List<Benefit> benefits = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(BenefitDaoImpl.Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                Benefit dbbenefit = map(resultSet);
                benefits.add(dbbenefit);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return benefits;
    }

    @Override
    public Benefit select(ConnectionManager manager, Long id) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(BenefitDaoImpl.Queries.SELECT_BY_PK, id);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    Benefit dbbenefit = map(resultSet);
                    return dbbenefit;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return null;
    }

//    @Override
//    public Location select(ConnectionManager manager, String username) {
//        try (PreparedStatement statement = manager.prepareStatementForSelect(UserDaoImpl.Queries.SELECT_BY_USERNAME, username);) {
//
//            try (ResultSet resultSet = statement.executeQuery();) {
//                while (resultSet.next()) {
//                    Location dblocation = map(resultSet);
//                    return dblocation;
//                }
//            }
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        }
//
//        return null;
//    }

    @Override
    public void insert(ConnectionManager manager, Benefit benefit) {
        Object[] values = reverse_map(benefit);

        try (PreparedStatement statement = manager.prepareStatementForInsert(BenefitDaoImpl.Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                benefit.setHouse_idhouse(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean update(ConnectionManager manager, Benefit benefit) {
        Object[] values = reverse_map_update(benefit);

        try (PreparedStatement statement = manager.prepareStatementForUpdate(BenefitDaoImpl.Queries.UPDATE, values);) {
            int output = statement.executeUpdate();
            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(ConnectionManager manager, Long key) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(BenefitDaoImpl.Queries.DELETE_BY_PK, key);) {
            int output = statement.executeUpdate();

            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }
    
}
