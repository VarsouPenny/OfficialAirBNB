/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import dbfactory.ConnectionManager;
import entities.Tenantreserveshouse;
import java.util.List;
/**
 *
 * @author rosa
 */
public interface TenantreserveshouseDao {
    public List<Tenantreserveshouse> select(ConnectionManager manager);
    
    public List<Tenantreserveshouse> select(ConnectionManager manager, String username);
    
    //public Location select(ConnectionManager manager, String username);
    
    public void insert(ConnectionManager manager, Tenantreserveshouse tenantreserveshouse);
    
    public boolean update(ConnectionManager manager, Tenantreserveshouse tenantreserveshouse);
    
    public boolean delete(ConnectionManager manager, Long key);

    public void rate(ConnectionManager cm, Long iduser,Long idhouse, int rate_value);
    
}
