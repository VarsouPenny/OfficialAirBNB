/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.User;
import java.util.List;

/**
 *
 * @author rosa
 */
public interface UserDao {

    public List<User> select(ConnectionManager manager);
    
    public User select(ConnectionManager manager, Long id);
    
    public User select(ConnectionManager manager, String username);
    
    public void insert(ConnectionManager manager, User user);
    
    public boolean update(ConnectionManager manager, User user);
    
    public boolean delete(ConnectionManager manager, Long key);

    public User activate(ConnectionManager cm, String username);

    public int getStars(ConnectionManager cm, String username);

   
}
