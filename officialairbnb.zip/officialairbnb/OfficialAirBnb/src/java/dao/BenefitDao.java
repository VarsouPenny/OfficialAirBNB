/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Benefit;
import java.util.List;
/**
 *
 * @author rosa
 */
public interface BenefitDao {
    
    public List<Benefit> select(ConnectionManager manager);
    
    public Benefit select(ConnectionManager manager, Long id);
    
    //public Location select(ConnectionManager manager, String username);
    
    public void insert(ConnectionManager manager, Benefit benefit);
    
    public boolean update(ConnectionManager manager, Benefit benefit);
    
    public boolean delete(ConnectionManager manager, Long key);
    
}
