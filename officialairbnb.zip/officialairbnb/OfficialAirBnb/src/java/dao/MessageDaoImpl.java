/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Message;
import entities.MessageList;
import entities.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rosa
 */
public class MessageDaoImpl implements MessageDao {

    class Queries {

        static final String SELECT_ALL = "SELECT * FROM message";
        static final String SELECT_BY_PK = "SELECT * FROM message WHERE message_id = ?";

        static final String SELECT_BY_SENDER = "SELECT * FROM message WHERE sender_iduser = (select iduser from user where username = ?)";
        static final String SELECT_BY_RECEIVER = "SELECT * FROM message WHERE receiver_iduser = (select iduser from user where username = ?)";

        //static final String SELECT_BY_USERNAME = "SELECT * FROM user WHERE username = ?";
        static final String UPDATE = "UPDATE message SET message= ?, sender_iduser = ?, receiver_iduser = ? WHERE message_id= ?";
        static final String INSERT = "INSERT INTO message(message, sender_iduser, receiver_iduser) VALUES (?,?,?)";
        static final String DELETE_BY_PK = "DELETE FROM message WHERE message_id = ?";
    }

    private static Message map(ResultSet row_ptr) throws SQLException {
        Message message = new Message();
        message.setMessage_id(row_ptr.getLong("message_id"));
        message.setMessage(row_ptr.getString("message"));
        message.setSender_iduser(row_ptr.getLong("sender_iduser"));
        message.setReceiver_iduser(row_ptr.getLong("receiver_iduser"));
        return message;
    }

    private static Object[] reverse_map(Message message) {
        Object[] values = new Object[]{
            message.getMessage(),
            message.getSender_iduser(),
            message.getReceiver_iduser(),};
        return values;
    }

    private static Object[] reverse_map_update(Message message) {
        Object[] values = new Object[]{
            message.getMessage(),
            message.getSender_iduser(),
            message.getReceiver_iduser()
        };
        return values;
    }

    @Override
    public List<Message> select(ConnectionManager manager) {
        List<Message> messages = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(MessageDaoImpl.Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                Message dbmessage = map(resultSet);
                messages.add(dbmessage);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return messages;
    }

    @Override
    public Message select(ConnectionManager manager, Long id) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(MessageDaoImpl.Queries.SELECT_BY_PK, id);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    Message dbmessage = map(resultSet);
                    return dbmessage;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<Message> select(ConnectionManager manager, String username) {
        List<Message> messages = new ArrayList<>();
        try (PreparedStatement statement = manager.prepareStatementForSelect(MessageDaoImpl.Queries.SELECT_BY_RECEIVER, username);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    Message dbmessage = map(resultSet);
                    messages.add(dbmessage);
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return messages;
    }

    @Override
    public void insert(ConnectionManager manager, Message message) {
        Object[] values = reverse_map(message);

        try (PreparedStatement statement = manager.prepareStatementForInsert(MessageDaoImpl.Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                message.setMessage_id(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean update(ConnectionManager manager, Message message) {
        Object[] values = reverse_map_update(message);

        try (PreparedStatement statement = manager.prepareStatementForUpdate(MessageDaoImpl.Queries.UPDATE, values);) {
            int output = statement.executeUpdate();
            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(ConnectionManager manager, Long key) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(MessageDaoImpl.Queries.DELETE_BY_PK, key);) {
            int output = statement.executeUpdate();

            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public MessageList select_inbox(ConnectionManager manager, String username) {
        MessageList messages = new MessageList();
        try (PreparedStatement statement = manager.prepareStatementForSelect(MessageDaoImpl.Queries.SELECT_BY_RECEIVER, username);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    Message dbmessage = map(resultSet);
                    messages.add(dbmessage);
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return messages;
    }

    @Override
    public MessageList select_outbox(ConnectionManager manager, String username) {
        MessageList messages = new MessageList();
        try (PreparedStatement statement = manager.prepareStatementForSelect(MessageDaoImpl.Queries.SELECT_BY_SENDER, username);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    Message dbmessage = map(resultSet);
                    messages.add(dbmessage);
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return messages;
    }

}
