/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.House;
import entities.HouseList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author rosa
 */
public interface HouseDao {
    
    public List<House> select(ConnectionManager manager);
    
    public House select(ConnectionManager manager, Long id);
    
    public HouseList selectForHousekeeper(ConnectionManager manager, String username);
    
    public HouseList selectForTenant(ConnectionManager manager, String username);
    
    //public House select(ConnectionManager manager, String username);
    
    public void insert(ConnectionManager manager, House house);
    
    public boolean update(ConnectionManager manager, House house);
    
    public boolean delete(ConnectionManager manager, Long key);  

    public HouseList search(ConnectionManager cm, Date fromdate, Date todate, String form_text, Long people, Boolean entirehome, Boolean privateroom, Boolean sharedroom, Long priceperday, Long bedroomnum, Long bathroomnum, Long bednum, Boolean livingroom, Boolean kitchen, Boolean smoking, Boolean pets, Boolean party, Boolean parking, Boolean elevator, Boolean wifi, Boolean aircondition, Boolean heating, Boolean tv, Long floor, Long dimension, String form_address, Boolean transportation);

    public int rate(ConnectionManager cm, Long idhouse, int rate);
}
