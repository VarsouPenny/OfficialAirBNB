/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Tenantreserveshouse;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rosa
 */
public class TenantreserveshouseDaoImpl implements TenantreserveshouseDao {

    class Queries {

        static final String SELECT_ALL = "SELECT * FROM tenant_reserves_house";
        static final String SELECT_BY_USER = "SELECT * FROM tenant_reserves_house WHERE user_iduser = (select iduser from user where username = ?)";
        static final String SELECT_BY_HOUSE = "SELECT * FROM tenant_reserves_house WHERE house_idhouse = ?";
        static final String SELECT_BY_HOUSEKEEPER = "SELECT * FROM tenant_reserves_house inner join house on house.idhouse = house_idhouse inner join user on user.iduser = user_iduser where fromdate > ? and todate < ?";

        //static final String SELECT_BY_USERNAME = "SELECT * FROM user WHERE username = ?";
        static final String UPDATE = "UPDATE tenant_reserves_house set has_rated = 1, rate_value = ? WHERE user_iduser= ? and house_idhouse = ?";
        static final String INSERT = "INSERT INTO tenant_reserves_house(user_iduser, house_idhouse, fromdate, todate, has_rated) VALUES (?,?,?,?,?)";
        static final String DELETE_BY_PK = "DELETE FROM benefit WHERE house_idhouse = ?";
    }

    private static Tenantreserveshouse map(ResultSet row_ptr) throws SQLException {
        Tenantreserveshouse tenantreserveshouse = new Tenantreserveshouse();
        tenantreserveshouse.setUser_iduser(row_ptr.getLong("user_iduser"));
        tenantreserveshouse.setHouse_idhouse(row_ptr.getLong("house_idhouse"));
        tenantreserveshouse.setFromdate(row_ptr.getDate("fromdate"));
        tenantreserveshouse.setTodate(row_ptr.getDate("todate"));
        tenantreserveshouse.setHas_rated(row_ptr.getBoolean("has_rated"));
        tenantreserveshouse.setRate(row_ptr.getInt("rate_value"));
        return tenantreserveshouse;
    }

    private static Object[] reverse_map(Tenantreserveshouse tenantreserveshouse) {
        Object[] values = new Object[]{
            tenantreserveshouse.getUser_iduser(),
            tenantreserveshouse.getHouse_idhouse(),
            tenantreserveshouse.getFromdate(),
            tenantreserveshouse.getTodate(),
            tenantreserveshouse.getHas_rated(),};
        return values;
    }

    private static Object[] reverse_map_update(Tenantreserveshouse tenantreserveshouse) {
        Object[] values = new Object[]{
            tenantreserveshouse.getRate(),
//            tenantreserveshouse.getHas_rated(),
            tenantreserveshouse.getUser_iduser(),
            tenantreserveshouse.getHouse_idhouse()
////            tenantreserveshouse.getFromdate(),
//            tenantreserveshouse.getTodate(),
            
        };
        return values;
    }

    @Override
    public List<Tenantreserveshouse> select(ConnectionManager manager) {
        List<Tenantreserveshouse> tenantreserveshouses = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(TenantreserveshouseDaoImpl.Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                Tenantreserveshouse dbtenantreserveshouse = map(resultSet);
                tenantreserveshouses.add(dbtenantreserveshouse);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return tenantreserveshouses;
    }

    @Override
    public List<Tenantreserveshouse> select(ConnectionManager manager, String username) {
        List<Tenantreserveshouse> tenantreserveshouses = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(TenantreserveshouseDaoImpl.Queries.SELECT_BY_USER, username);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                Tenantreserveshouse dbtenantreserveshouse = map(resultSet);
                tenantreserveshouses.add(dbtenantreserveshouse);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return tenantreserveshouses;
    }

//    @Override
//    public Location select(ConnectionManager manager, String username) {
//        try (PreparedStatement statement = manager.prepareStatementForSelect(UserDaoImpl.Queries.SELECT_BY_USERNAME, username);) {
//
//            try (ResultSet resultSet = statement.executeQuery();) {
//                while (resultSet.next()) {
//                    Location dblocation = map(resultSet);
//                    return dblocation;
//                }
//            }
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        }
//
//        return null;
//    }
    @Override
    public void insert(ConnectionManager manager, Tenantreserveshouse tenantreserveshouse) {
        Object[] values = reverse_map(tenantreserveshouse);

        try (PreparedStatement statement = manager.prepareStatementForInsert(TenantreserveshouseDaoImpl.Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                tenantreserveshouse.setHouse_idhouse(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean update(ConnectionManager manager, Tenantreserveshouse tenantreserveshouse) {
        Object[] values = reverse_map_update(tenantreserveshouse);

        try (PreparedStatement statement = manager.prepareStatementForUpdate(TenantreserveshouseDaoImpl.Queries.UPDATE, values);) {
            int output = statement.executeUpdate();
            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(ConnectionManager manager, Long key
    ) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(TenantreserveshouseDaoImpl.Queries.DELETE_BY_PK, key);) {
            int output = statement.executeUpdate();

            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }
    
    @Override    
    public void rate(ConnectionManager cm, Long iduser, Long idhouse, int rate_value) {
        Tenantreserveshouse ent = new Tenantreserveshouse();
        ent.setUser_iduser(iduser);
        ent.setHouse_idhouse(idhouse);
        ent.setRate(rate_value);
        
        update(cm, ent);
    }
}
