/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;



import dbfactory.ConnectionManager;
import entities.Space;
import java.util.List;
/**
 *
 * @author rosa
 */
public interface SpaceDao {
    
    public List<Space> select(ConnectionManager manager);
    
    public Space select(ConnectionManager manager, Long id);
    
    //public Location select(ConnectionManager manager, String username);
    
    public void insert(ConnectionManager manager, Space space);
    
    public boolean update(ConnectionManager manager, Space space);
    
    public boolean delete(ConnectionManager manager, Long key);
    
}
