/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rosa
 */
public class UserDaoImpl implements UserDao {


    class Queries {

        static final String SELECT_ALL = "SELECT * FROM user order by lastname";
        static final String SELECT_STARS_BY_USERNAME = "SELECT avg(stars) as stars FROM user inner join house where house.housekeeper_id = user.iduser and username = ?";
        static final String SELECT_BY_PK = "SELECT * FROM user WHERE iduser = ?";
        static final String SELECT_BY_USERNAME = "SELECT * FROM user WHERE username = ?";
        static final String ACTIVATE = "UPDATE user SET activated = 1 where username = ?";
        static final String UPDATE = "UPDATE user SET password = ?, lastname = ?, firstname = ?, email = ?, phonenumber = ?, photo = ? WHERE username = ?";
        static final String INSERT = "INSERT INTO user(username, password, lastname, firstname, email, phonenumber, photo, tenant, housekeeper, administrator, activated) VALUES (?,?,?,?,?,?,?,?,?,false, false)";
        static final String DELETE_BY_PK = "DELETE FROM user WHERE iduser = ?";
    }

    private static int mapStars(ResultSet row_ptr) throws SQLException {
        double stars = 0;
        stars = row_ptr.getDouble("stars");
        int rounded = (int)stars;
        return rounded;
    }
    private static User map(ResultSet row_ptr) throws SQLException {
        User user = new User();
        user.setIduser(row_ptr.getLong("iduser"));
        user.setUsername(row_ptr.getString("username"));
        user.setPassword(row_ptr.getString("password"));
        user.setLastname(row_ptr.getString("lastname"));
        user.setFirstname(row_ptr.getString("firstname"));
        user.setEmail(row_ptr.getString("email"));
        user.setPhonenumber(row_ptr.getString("phonenumber"));
        user.setPhoto(row_ptr.getString("photo"));
        user.setTenant(row_ptr.getBoolean("tenant"));
        user.setHousekeeper(row_ptr.getBoolean("housekeeper"));
        user.setAdministrator(row_ptr.getBoolean("administrator"));
        user.setActivated(row_ptr.getBoolean("activated"));
        return user;
    }

    private static Object[] reverse_map(User user) {
        Object[] values = new Object[]{
            user.getUsername(),
            user.getPassword(),
            user.getLastname(),
            user.getFirstname(),
            user.getEmail(),
            user.getPhonenumber(),
            user.getPhoto(),
            user.getTenant(),
            user.getHousekeeper()
        };
        return values;
    }

    private static Object[] reverse_map_update(User user) {
        Object[] values = new Object[]{
            user.getPassword(),
            user.getLastname(),
            user.getFirstname(),
            user.getEmail(),
            user.getPhonenumber(),
            user.getPhoto(),
            user.getUsername()
        };
        return values;
    }

    @Override
    public List<User> select(ConnectionManager manager) {
        List<User> users = new ArrayList<>();

        try (
                PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_ALL);
                ResultSet resultSet = statement.executeQuery();) {
            while (resultSet.next()) {
                User dbuser = map(resultSet);
                users.add(dbuser);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return users;
    }

    @Override
    public User select(ConnectionManager manager, Long id) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_BY_PK, id);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    User dbuser = map(resultSet);
                    return dbuser;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return null;
    }

    @Override
    public User select(ConnectionManager manager, String username) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_BY_USERNAME, username);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                while (resultSet.next()) {
                    User dbuser = map(resultSet);
                    return dbuser;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return null;
    }

    @Override
    public void insert(ConnectionManager manager, User user) {
        Object[] values = reverse_map(user);

        try (PreparedStatement statement = manager.prepareStatementForInsert(Queries.INSERT, values);) {

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();

            if (rs.next()) {
                Long key = rs.getLong(1);
                user.setIduser(key);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public boolean update(ConnectionManager manager, User user) {
        Object[] values = reverse_map_update(user);

        try (PreparedStatement statement = manager.prepareStatementForUpdate(Queries.UPDATE, values);) {
            int output = statement.executeUpdate();
            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(ConnectionManager manager, Long key) {
        try (PreparedStatement statement = manager.prepareStatementForSelect(Queries.DELETE_BY_PK, key);) {
            int output = statement.executeUpdate();

            return output > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }
    
    @Override
    public User activate(ConnectionManager manager, String username) {
        
        try (PreparedStatement statement = manager.prepareStatementForUpdate(Queries.ACTIVATE, username);) {
            statement.executeUpdate();
                        
            return select(manager, username);
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    @Override
    public int getStars(ConnectionManager manager, String username) {
         try (PreparedStatement statement = manager.prepareStatementForSelect(Queries.SELECT_STARS_BY_USERNAME, username);) {

            try (ResultSet resultSet = statement.executeQuery();) {
                if (resultSet.next()) {
                    int stars = mapStars(resultSet);
                    return stars;
                }
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return 1;
    }
    
}
