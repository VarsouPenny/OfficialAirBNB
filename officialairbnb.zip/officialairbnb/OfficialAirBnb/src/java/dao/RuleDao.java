/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbfactory.ConnectionManager;
import entities.Rule;
import java.util.List;
/**
 *
 * @author rosa
 */
public interface RuleDao {
    
    public List<Rule> select(ConnectionManager manager);
    
    public Rule select(ConnectionManager manager, Long id);
    
    //public Location select(ConnectionManager manager, String username);
    
    public void insert(ConnectionManager manager, Rule rule);
    
    public boolean update(ConnectionManager manager, Rule rule);
    
    public boolean delete(ConnectionManager manager, Long key);
}
