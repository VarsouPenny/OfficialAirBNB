/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import dao.HouseDaoImpl;
import dao.RuleDaoImpl;
import dao.SpaceDaoImpl;
import dbfactory.ConnectionManager;
import entities.House;
import entities.Rule;
import entities.Space;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rosa
 */
@WebServlet(name = "Debugger", urlPatterns = {"/Debugger"})
public class Debugger extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Debugger</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Debugger at " + request.getContextPath() + "</h1>");
 
            ConnectionManager cm = new ConnectionManager();
            
            
            
            
            
            
            
            
            
            
//--------------------------------benefit debugger-------------------------------------------------------------------------------------
//            BenefitDaoImpl dao = new BenefitDaoImpl();
//
//            List<Benefit> benefits = dao.select(cm);
//
//            out.println("<h1>select all benefit</h1>");
//            for (Benefit l : benefits) {
//                out.println(l + "<BR/>");
//            }
//
//            out.println("<h1>select one benefit by id</h1>");
//
//            Benefit l = dao.select(cm, 2L);
//
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("benefit not found for id = 1 <BR/>");
//            }
//
//            //out.println("<h1>select one house by username</h1>");
//
//           // u = dao.select(cm, "m");
//
////            if (u != null) {
////                out.println(u + "<BR/>");
////            } else {
////                out.println("house not found for username m <BR/>");
////            }
//            
//            out.println("<h1>testing insert for one benefit </h1>");
//
//            Benefit newbenefit = new Benefit();
//
//            newbenefit.setHouse_idhouse(5L);
//            newbenefit.setWifi(true);
//            newbenefit.setAircondition(false);
//            newbenefit.setHeating(false);
//            newbenefit.setTv(true);
//            newbenefit.setParking(false);
//            newbenefit.setElevator(false);
//            newbenefit.setHeating(false);
//            newbenefit.setKitchen(false);
//            
//            
//            dao.insert(cm, newbenefit);   
//            
//            out.println("Id is " +  newbenefit.getHouse_idhouse() + "  <br/>");
//            
//            Long id = newbenefit.getHouse_idhouse();  
//            
//            out.println("<h1>testing update for benefit with id " + id + " </h1>");
//            
//            l = dao.select(cm, id);
//            
//            out.println(l + "<BR/>");
//            
//            l.setWifi(false);
//            
//            dao.update(cm, l);
//            
//            out.println(l + "<BR/>");
//            
//            out.println("<h1>testing delete for benefit with id " + id + " </h1>");
//            
//            dao.delete(cm, id);
//            
//            l = dao.select(cm, id);
//            
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("benefit not found for id = 3 <BR/>");
//            } 
//







//---------------------------------------------message debugger---------------------------------------------------------------
//            ConnectionManager cm = new ConnectionManager();
//            MessageDaoImpl dao = new MessageDaoImpl();
//
//            List<Message> messages = dao.select(cm);
//
//            out.println("<h1>select all messages</h1>");
//            for (Message l : messages) {
//                out.println(l + "<BR/>");
//            }
//
//            out.println("<h1>select one message by id</h1>");
//
//            Message l = dao.select(cm, 2L);
//
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("message not found for id = 1 <BR/>");
//            }
//
//            //out.println("<h1>select one house by username</h1>");
//
//           // u = dao.select(cm, "m");
//
////            if (u != null) {
////                out.println(u + "<BR/>");
////            } else {
////                out.println("house not found for username m <BR/>");
////            }
//            
//            out.println("<h1>testing insert for one message </h1>");
//
//            Message newmessage = new Message();
//
//            newmessage.setMessage_id(5L);
//            newmessage.setMessage("eimai o theos");
//            newmessage.setSender_iduser(4L);
//            newmessage.setReceiver_iduser(5L);
//            
//            
//            dao.insert(cm, newmessage);   
//            
//            out.println("Id is " +  newmessage.getMessage_id() + "  <br/>");
//            
//            Long id = newmessage.getMessage_id();  
//            
//            out.println("<h1>testing update for message with id " + id + " </h1>");
//            
//            l = dao.select(cm, id);
//            
//            out.println(l + "<BR/>");
//            
//            l.setMessage("ola popa");
//            
//            dao.update(cm, l);
//            
//            out.println(l + "<BR/>");
//            
//           // out.println("<h1>testing delete for message with id " + id + " </h1>");
//            
//            //dao.delete(cm, id);
//            
////            l = dao.select(cm, id);
////            
////            if (l != null) {
////                out.println(l + "<BR/>");
////            } else {
////                out.println("space not found for id = 3 <BR/>");
////            } 
//            
           
            
            
            
            
//------------------------------------------space debugger-----------------------------------------------------------------------------------------------------           
//            SpaceDaoImpl dao = new SpaceDaoImpl();
//
//            List<Space> spaces = dao.select(cm);
//
//            out.println("<h1>select all spaces</h1>");
//            for (Space l : spaces) {
//                out.println(l + "<BR/>");
//            }
//
//            out.println("<h1>select one space by id</h1>");
//
//            Space l = dao.select(cm, 2L);
//
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("space not found for id = 1 <BR/>");
//            }
//
//            //out.println("<h1>select one house by username</h1>");
//
//           // u = dao.select(cm, "m");
//
////            if (u != null) {
////                out.println(u + "<BR/>");
////            } else {
////                out.println("house not found for username m <BR/>");
////            }
//            
//            out.println("<h1>testing insert for one location </h1>");
//
//            Space newspace = new Space();
//
//            newspace.setHouse_idhouse(5L);
//            newspace.setBednum(4L);
//            newspace.setBathnum(4L);
//            newspace.setPrivateroom(true);
//            newspace.setPublicroom(true);
//            newspace.setWholehouse(true);
//            newspace.setBedroomnum(5L);
//            newspace.setLivingroom(true);
//            newspace.setDimension(40L);
//            
//            dao.insert(cm, newspace);   
//            
//            out.println("Id is " +  newspace.getHouse_idhouse() + "  <br/>");
//            
//            Long id = newspace.getHouse_idhouse();  
//            
//            out.println("<h1>testing update for space with id " + id + " </h1>");
//            
//            l = dao.select(cm, id);
//            
//            out.println(l + "<BR/>");
//            
//            l.setPrivateroom(false);
//            
//            dao.update(cm, l);
//            
//            out.println(l + "<BR/>");
//            
//            out.println("<h1>testing delete for space with id " + id + " </h1>");
//            
//            dao.delete(cm, id);
//            
//            l = dao.select(cm, id);
//            
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("space not found for id = 3 <BR/>");
//            } 
//            
           
            
            
            
            
            
//-----------------------------------rules debugger----------------------------------------------------------------            
//            //ConnectionManager cm = new ConnectionManager();
//            RuleDaoImpl dao = new RuleDaoImpl();
//
//            List<Rule> rules = dao.select(cm);
//
//            out.println("<h1>select all Rules</h1>");
//            for (Rule l : rules) {
//                out.println(l + "<BR/>");
//            }
//
//            out.println("<h1>select one Rules by id</h1>");
//
//            Rule l = dao.select(cm, 2L);
//
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("Rules not found for id = 1 <BR/>");
//            }
//
//            //out.println("<h1>select one house by username</h1>");
//
//           // u = dao.select(cm, "m");
//
////            if (u != null) {
////                out.println(u + "<BR/>");
////            } else {
////                out.println("house not found for username m <BR/>");
////            }
//            
//            out.println("<h1>testing insert for one rules </h1>");
//
//            Rule newrule = new Rule();
//
//            newrule.setHouse_idhouse(5L);
//            newrule.setSmoking(true);
//            newrule.setPets(false);
//            newrule.setParty(true);
//            newrule.setParking(true);
//            newrule.setMinimumdays(6L);
//            newrule.setExtraperperson(60L);
//            
//            dao.insert(cm, newrule);   
//            
//            out.println("Id is " +  newrule.getHouse_idhouse() + "  <br/>");
//            
//            Long id = newrule.getHouse_idhouse();  
//            
//            out.println("<h1>testing update for rules with id " + id + " </h1>");
//            
//            l = dao.select(cm, id);
//            
//            out.println(l + "<BR/>");
//            
//            l.setExtraperperson(40L);
//            
//            dao.update(cm, l);
//            
//            out.println(l + "<BR/>");
//            
//            out.println("<h1>testing delete for rules with id " + id + " </h1>");
//            
//            dao.delete(cm, id);
//            
//            l = dao.select(cm, id);
//            
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("Rules not found for id = 3 <BR/>");
//            }
//            
//            
            
            
//---------------------------location debugger-----------------------------------------------------------------------------------------------------------------
//            ConnectionManager cm = new ConnectionManager();
//            LocationDaoImpl dao = new LocationDaoImpl();
//
//            List<Location> locations = dao.select(cm);
//
//            out.println("<h1>select all locations</h1>");
//            for (Location l : locations) {
//                out.println(l + "<BR/>");
//            }
//
//            out.println("<h1>select one location by id</h1>");
//
//            Location l = dao.select(cm, 2L);
//
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("location not found for id = 1 <BR/>");
//            }
//
//            //out.println("<h1>select one house by username</h1>");
//
//           // u = dao.select(cm, "m");
//
////            if (u != null) {
////                out.println(u + "<BR/>");
////            } else {
////                out.println("house not found for username m <BR/>");
////            }
//            
//            out.println("<h1>testing insert for one location </h1>");
//
//            Location newlocation = new Location();
//
//            newlocation.setHouse_idhouse(5L);
//            newlocation.setAddress("newaddress");
//            newlocation.setNeighborhood("neighbor");
//            newlocation.setTransport("bus");
//            
//            dao.insert(cm, newlocation);   
//            
//            out.println("Id is " +  newlocation.getHouse_idhouse() + "  <br/>");
//            
//            Long id = newlocation.getHouse_idhouse();  
//            
//            out.println("<h1>testing update for location with id " + id + " </h1>");
//            
//            l = dao.select(cm, id);
//            
//            out.println(l + "<BR/>");
//            
//            l.setAddress("oldaddress");
//            
//            dao.update(cm, l);
//            
//            out.println(l + "<BR/>");
//            
//            out.println("<h1>testing delete for location with id " + id + " </h1>");
//            
//            dao.delete(cm, id);
//            
//            l = dao.select(cm, id);
//            
//            if (l != null) {
//                out.println(l + "<BR/>");
//            } else {
//                out.println("location not found for id = 3 <BR/>");
//            }
//------------------------------------------House Debugger--------------------------------------------------------------------------
//            ConnectionManager cm = new ConnectionManager();
//            HouseDaoImpl dao = new HouseDaoImpl();
//
//            List<House> houses = dao.select(cm);
//
//            out.println("<h1>select all houses</h1>");
//            for (House u : houses) {
//                out.println(u + "<BR/>");
//            }
//
//            out.println("<h1>select one house by id</h1>");
//
//            House h = dao.select(cm, 3L);
//
//            if (h != null) {
//                out.println(h + "<BR/>");
//            } else {
//                out.println("house not found for id = 1 <BR/>");
//            }
//
//            //out.println("<h1>select one house by username</h1>");
//
//           // u = dao.select(cm, "m");
//
////            if (u != null) {
////                out.println(u + "<BR/>");
////            } else {
////                out.println("house not found for username m <BR/>");
////            }
//            
//            out.println("<h1>testing insert for one house </h1>");
//
//            House newhouse = new House();
//
//            newhouse.setPriceperday(50L);
//            newhouse.setPeople(2L);
//            newhouse.setFloor(4L);
//            newhouse.setFromdate("2017-10-3");
//            newhouse.setTodate("2017-10-13");
//            newhouse.setCountry("jkhfsdiu");
//            newhouse.setCity("athens");
//            newhouse.setStars(2L);
//            newhouse.setDescription("all good");
//            newhouse.setHousekeeper_id(1L);
//            
//            dao.insert(cm, newhouse);   
//            
//            out.println("Id is " +  newhouse.getIdhouse() + "  <br/>");
//            
//            Long id = newhouse.getIdhouse();            
//            
//            out.println("<h1>testing update for user with id " + id + " </h1>");
//            
//            h = dao.select(cm, id);
//            
//            out.println(h + "<BR/>");
//            
//            h.setCity("kalamata");
//            
//            dao.update(cm, h);
//            
//            out.println(h + "<BR/>");
//            
//            out.println("<h1>testing delete for house with id " + id + " </h1>");
//            
//            dao.delete(cm, id);
//            
//            h = dao.select(cm, id);
//            
//            if (h != null) {
//                out.println(h + "<BR/>");
//            } else {
//                out.println("user not found for id = 1 <BR/>");
//            }
//            

            
            

            cm.close();

            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
