/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class DoProfileController implements LoaderController {

    @Override
    public void prepare(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();

        String username = session.getAttribute("username").toString();

        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();

        User user = dao.select(cm, username);
        int stars = dao.getStars(cm, username);

        if (user == null) {
            throw new Exception("invalid token");
        } else {
            request.setAttribute("user", user);
            request.setAttribute("stars", stars);
        }
    }

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // load all posted parameters to local variables
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String email = request.getParameter("email");
        String photo = request.getParameter("photo");
        String phonenumber = request.getParameter("phonenumber");

//        // validation username
//        if (username == null /* || username.length() < 3 */) {
//            throw new Exception("username must be at least 3 letters long");
//        }
//
//        // validation password
//        if (password == null) {
//            throw new Exception("password is missing");
//        }
        // check if username exists
        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setFirstname(firstname);
        user.setLastname(lastname);
        user.setEmail(email);
        user.setPhoto(photo);
        user.setPhonenumber(phonenumber);

        Boolean success = dao.update(cm, user);
        if (success == true) {
            cm.close();
        } else {
            cm.close();
            throw new Exception("update failed");
        }
    }

}
