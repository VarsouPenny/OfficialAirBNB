/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.HouseDao;
import dao.HouseDaoImpl;
import dbfactory.ConnectionManager;
import entities.HouseList;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rosa
 */
public class DoSearchController implements Controller {

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // load all posted parameters to local variables
        String form_fromdate = request.getParameter("fromdate");
        String form_todate = request.getParameter("todate");
        String form_text = request.getParameter("text");
        String form_people = request.getParameter("people");

        /* advanced parameters */
        String form_entirehome = request.getParameter("entirehome");
        String form_privateroom = request.getParameter("privateroom");
        String form_sharedroom = request.getParameter("sharedroom");
        String form_priceperday = request.getParameter("priceperday");
        String form_bedroomnum = request.getParameter("bedroomnum");
        String form_bathroomnum = request.getParameter("bathroomnum");
        String form_bednum = request.getParameter("bednum");
        String form_livingroom = request.getParameter("livingroom");
        String form_kitchen = request.getParameter("kitchen");
        String form_smoking = request.getParameter("smoking");
        String form_pets = request.getParameter("pets");
        String form_party = request.getParameter("party");
        String form_parking = request.getParameter("parking");
        String form_elevator = request.getParameter("elevator");
        String form_wifi = request.getParameter("wifi");
        String form_aircondition = request.getParameter("aircondition");
        String form_heating = request.getParameter("heating");
        String form_tv = request.getParameter("tv");
        String form_floor = request.getParameter("floor");
        String form_dimension = request.getParameter("dimension");
        String form_address = request.getParameter("address");
        String form_transportation = request.getParameter("transportation");
        
        Date fromdate = null;
        Date todate = null;
        Long people = null;
        Boolean entirehome = null;
        Boolean privateroom = null;
        Boolean sharedroom = null;
        Long priceperday = null;
        
        Long bedroomnum = null; // space
        Long bathroomnum = null;
        Long bednum = null;
        
        Boolean livingroom = null;
        Boolean kitchen = null;
        Boolean smoking = null;
        Boolean pets = null;
        Boolean party = null;
        Boolean parking = null;
        Boolean elevator = null;
        Boolean wifi = null;
        Boolean aircondition = null;
        Boolean heating = null;
        Boolean tv = null;
        Long dimension = null;
        Boolean transportation = null;
        Long floor = null;
        
        // validation fromdate
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        try {
            fromdate = format.parse(form_fromdate);
        } catch (ParseException ex) {
            throw new Exception("invalid date format for from date");
        }
        
        try {
            todate = format.parse(form_todate);
        } catch (ParseException ex) {
            throw new Exception("invalid date format for to date");
        }

        try {
            if (form_people != null && form_people.trim().length() > 0) {
                people = Long.parseLong(form_people);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid number for people");
        }
        
        try {
            if (form_priceperday != null && form_priceperday.trim().length() > 0) {
                priceperday = Long.parseLong(form_priceperday);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid priceperday");
        }
        
        try {
            if (form_bedroomnum != null && form_bedroomnum.trim().length() > 0) {
                bedroomnum = Long.parseLong(form_bedroomnum);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bedroomnum");
        }
        
        try {
            if (form_bathroomnum != null && form_bathroomnum.trim().length() > 0) {
                bathroomnum = Long.parseLong(form_bathroomnum);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bathroomnum");
        }
        
        try {
            if (form_bednum != null && form_bednum.trim().length() > 0) {
                bednum = Long.parseLong(form_bednum);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bednum");
        }
        try {
            if (form_dimension != null && form_dimension.trim().length() > 0) {
                dimension = Long.parseLong(form_dimension);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid dimension");
        }
        
         try {
            if (form_floor != null && form_floor.trim().length() > 0) {
                floor = Long.parseLong(form_floor);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid floor");
        }

        if (form_entirehome != null) {
            entirehome = true;
        }
        
        if (form_privateroom != null) {
            privateroom = true;
        }
        
        if (form_sharedroom != null) {
            sharedroom = true;
        }
        
        if (form_livingroom != null) {
            livingroom = true;
        } 
        
        if (form_kitchen != null) {
            kitchen = true;
        }
        
        if (form_smoking != null) {
            smoking = true;
        }
        
        if (form_pets != null) {
            pets = true;
        }
        
        if (form_party != null) {
            party = true;
        }
        
        if (form_parking != null) {
            parking = true;
        }
        
        if (form_elevator != null) {
            elevator = true;
        }

        if (form_wifi != null) {
            wifi = true;
        }
        
        if (form_aircondition != null) {
            elevator = true;
        }
        
        if (form_heating != null) {
            heating = true;
        }
        
        if (form_tv != null) {
            tv = true;
        }
        
        if (form_transportation != null) {
            transportation = true;
        }
       
        // ----------------- we are ready for search
        // check if username exists
        ConnectionManager cm = new ConnectionManager();
        HouseDao dao = new HouseDaoImpl();

        HouseList houses;
        houses = dao.search(cm, fromdate, todate, form_text, people, entirehome, privateroom, sharedroom, priceperday, bedroomnum, bathroomnum, bednum, livingroom, kitchen, smoking, pets, party, parking, elevator, wifi, aircondition, heating, tv, floor, dimension, form_address, transportation);

        request.setAttribute("houselist", houses);

        request.setAttribute("fromdate", form_fromdate);
        request.setAttribute("todate", form_todate);
        
        if (form_text != null) {
            request.setAttribute("text", form_text);
        }
        if (form_people != null) {
            request.setAttribute("people", form_people);
        }
        
        if (form_entirehome != null) {
            request.setAttribute("entirehome", form_entirehome);
        }
        
        if (form_privateroom != null) {
            request.setAttribute("privateroom", form_privateroom);
        }
        
        if (form_sharedroom != null) {
            request.setAttribute("sharedroom", form_sharedroom);
        }
        
        if (form_bedroomnum != null) {
            request.setAttribute("bedroomnum", form_bedroomnum);
        }
        
        if (form_bathroomnum != null) {
            request.setAttribute("bathnum", form_bathroomnum);
        }
        
        if (form_bednum != null) {
            request.setAttribute("bednum", form_bednum);
        }
        
        if (form_livingroom != null) {
            request.setAttribute("livingroom", form_livingroom);
        }
        if (form_kitchen != null) {
            request.setAttribute("kitchen", form_kitchen);
        }
        if (form_smoking != null) {
            request.setAttribute("smoking", form_smoking);
        }
        
        if (form_pets != null) {
            request.setAttribute("pets", form_pets);
        }
        
        if (form_party != null) {
            request.setAttribute("party", form_party);
        }
        
        if (form_parking != null) {
            request.setAttribute("parking", form_parking);
        }
        
        if (form_elevator != null) {
            request.setAttribute("elevator", form_elevator);
        }
        
        if (form_wifi != null) {
            request.setAttribute("wifi", form_wifi);
        }
        if (form_aircondition != null) {
            request.setAttribute("aircondition", form_aircondition);
        }
        if (form_heating != null) {
            request.setAttribute("heating", form_heating);
        }
        if (form_tv != null) {
            request.setAttribute("tv", form_tv);
        }
        if (form_dimension != null) {
            request.setAttribute("dimension", form_dimension);
        }
        if (form_address != null) {
            request.setAttribute("address", form_address);
        }
        if (form_transportation != null) {
            request.setAttribute("transportation", form_transportation);
        }
        if (form_priceperday != null) {
            request.setAttribute("priceperday", form_priceperday);
        }
        
        cm.close();
    }

}
