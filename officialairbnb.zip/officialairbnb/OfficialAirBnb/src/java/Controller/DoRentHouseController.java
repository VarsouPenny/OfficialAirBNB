/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.TenantreserveshouseDao;
import dao.TenantreserveshouseDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.House;
import entities.User;
import entities.Tenantreserveshouse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class DoRentHouseController implements Controller {

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // load all posted parameters to local variables
        HttpSession session = request.getSession();

        String username_renter = session.getAttribute("username").toString();
        String house_idhouse = request.getParameter("idhouse");
        String form_fromdate = request.getParameter("fromdate");
        String form_todate = request.getParameter("todate");
        Date fromdate, todate;

        if (username_renter == null) {
            throw new Exception("invalid token");
        }

        if (form_fromdate == null) {
            throw new Exception("invalid date");
        }

        if (form_todate == null) {
            throw new Exception("invalid date");
        }

        if (house_idhouse == null) {
            throw new Exception("invalid date");
        }
        
        // validation fromdate
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        try {
            fromdate = format.parse(form_fromdate);
        } catch (ParseException ex) {
            throw new Exception("invalid date format for from date");
        }
        
        try {
            todate = format.parse(form_todate);
        } catch (ParseException ex) {
            throw new Exception("invalid date format for to date");
        }

        // check if username already exists
        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();

        User renter = dao.select(cm, username_renter);

        Long id = renter.getIduser();
        Long idhouse = Long.parseLong(house_idhouse);

        Tenantreserveshouse tenantreserveshouse = new Tenantreserveshouse();
        tenantreserveshouse.setUser_iduser(id);
        tenantreserveshouse.setHouse_idhouse(idhouse);
        tenantreserveshouse.setFromdate(fromdate);
        tenantreserveshouse.setTodate(todate);
        tenantreserveshouse.setHas_rated(false);

        TenantreserveshouseDao trddao = new TenantreserveshouseDaoImpl();
        
        trddao.insert(cm, tenantreserveshouse);
        
        // free resources
        cm.close();
    }
}
