/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.User;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class DoActivateController implements LoaderController {

    @Override
    public void prepare(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();

        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();

        List<User> users = dao.select(cm);

        request.setAttribute("userlist", users);
    }

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String username = request.getParameter("username").toString();

        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();

        User user = dao.activate(cm, username);

        if (user == null) {
            throw new Exception("invalid token");
        } else {
            request.setAttribute("user", user);
        }
    }

}
