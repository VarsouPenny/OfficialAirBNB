/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.HouseDao;
import dao.HouseDaoImpl;
import dao.TenantVisitshouseDao;
import dao.TenantVisitshouseDaoImpl;
import dao.TenantreserveshouseDao;
import dao.TenantreserveshouseDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import datastructures.HouseNode;
import datastructures.Node;
import datastructures.UserNode;
import dbfactory.ConnectionManager;
import entities.House;
import entities.HouseList;
import entities.Tenantreserveshouse;
import entities.Tenantvisitshouse;
import entities.User;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sun.java2d.pipe.SpanShapeRenderer;

/**
 *
 * @author mirka
 */
public class ViewMyRecommendedHouses implements LoaderController {

    @Override
    public void prepare(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();

        String username = session.getAttribute("username").toString();

        ConnectionManager cm = new ConnectionManager();

        UserDao udao = new UserDaoImpl();
        HouseDao hdao = new HouseDaoImpl();
        TenantreserveshouseDao tdao = new TenantreserveshouseDaoImpl();
        TenantVisitshouseDao vdao = new TenantVisitshouseDaoImpl();

        User loginUser = udao.select(cm, username);

        Long id = loginUser.getIduser();
        UserNode loginNode = null;

        // fill list ...
        // database data
        List<User> allusers = udao.select(cm);
        List<House> allhouses = hdao.select(cm);
        List<Tenantreserveshouse> allrates = tdao.select(cm);
        List<Tenantvisitshouse> allvisits = vdao.select(cm);

        // memory model
        List<UserNode> userNodes = new ArrayList<>();
        List<HouseNode> houseNodes = new ArrayList<>();
        List<HouseNode> mayBeRecommended = new ArrayList<>();

        // create data structure
        for (User u : allusers) {
            UserNode un = new UserNode(u.getIduser());
            
            if(u.getIduser() == id) {
                loginNode = un;
            }

            for (House h : allhouses) {
                HouseNode hn = null;

                for (HouseNode temp : houseNodes) {
                    if (h == temp.house) {
                        hn = temp;
                        break;
                    }
                }

                if (hn == null) {
                    hn = new HouseNode(h);
                }

                int ratings = 0;
                for (Tenantreserveshouse t : allrates) {
                    if (t.getUser_iduser().equals(u.getIduser())) {
                        ratings++;
                    }
                }

                if (ratings > 0) {
                    for (Tenantreserveshouse t : allrates) {
                        if (t.getUser_iduser().equals(u.getIduser()) && t.getHouse_idhouse().equals(h.getIdhouse())) {
                            Node n = new Node(un, t.getRate().floatValue());
                            un.nodes.add(n);
                            hn.nodes.add(n);
                            ratings++;
                        } else {
                            Node n = new Node(un, Float.NEGATIVE_INFINITY);
                            un.nodes.add(n);
                            hn.nodes.add(n);
                        }
                    }
                } else {
                    for (Tenantvisitshouse t : allvisits) {
                        if (t.getUser_iduser().equals(u.getIduser()) && t.getHouse_idhouse().equals(h.getIdhouse())) {
                            Node n = new Node(un, 2f);
                            un.nodes.add(n);
                            hn.nodes.add(n);
                        } else {
                            Node n = new Node(un, Float.NEGATIVE_INFINITY);
                            un.nodes.add(n);
                            hn.nodes.add(n);
                        }
                    }
                }

                houseNodes.add(hn);
            }

            userNodes.add(un);
        }

        // find which houses can be recommended
        for (HouseNode temp : houseNodes) {
            for (Tenantreserveshouse t : allrates) {
                if (t.getUser_iduser().equals(id) && t.getHouse_idhouse().equals(temp.house.getIdhouse())) {
                    temp.may_be_recommended = false;
                }
            }
        }

        // fill list with recommended houses
        for (HouseNode temp : houseNodes) {
            if (temp.may_be_recommended) {
                mayBeRecommended.add(temp);
            }
        }

        // normalization
        for (UserNode un : userNodes) {
            float sum = 0, denom = 0, sumquared = 0;
            for (Node n : un.nodes) {
                if (n.value.isInfinite() == false) {
                    sum += n.value;
                    sumquared += (n.value * n.value);

                    denom++;
                }
            }

            if (denom != 0) {
                float avg = sum / denom;

                for (Node n : un.nodes) {
                    if (n.value.isInfinite() == false) {
                        n.value -= avg;
                    } else {
                        n.value = 0f;
                    }
                }
            }

            un.norm = (float) Math.sqrt(sumquared);
        }

        // calculate similarities
        for (UserNode un1 : userNodes) {
            for (UserNode un2 : userNodes) {
                float sum = 0;

                Iterator<Node> p = un1.nodes.iterator();
                Iterator<Node> q = un2.nodes.iterator();

                while (p.hasNext() && q.hasNext()) {
                    Node n1 = p.next();
                    Node n2 = q.next();

                    sum = sum + n1.value * n2.value;
                }

                if (un1.norm != 0 && un2.norm != 0) {
                    un1.similarities.put(un2, sum / (un1.norm * un2.norm));
                } else {
                    un1.similarities.put(un2, 0f);
                }
            }
        }

        // rate toberecommended houses
        for (HouseNode temp : mayBeRecommended) {
            for (Node n : temp.nodes) {
                temp.score += n.value*n.user.similarities.get(loginNode);
            }
        }
        
        Collections.sort(mayBeRecommended);
        
        HouseList houselist = new HouseList();
        
        Iterator<HouseNode> p = mayBeRecommended.iterator();
        
        int finalcountdown = 4;
        
        while (finalcountdown > 0 && p.hasNext()) {
            HouseNode hn =  p.next();
            houselist.add(hn.house);
                    
            finalcountdown--;
        }
        
        request.setAttribute("houselist", houselist);
    }

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
