/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.MessageDao;
import dao.MessageDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.Message;
import entities.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class DoCreateMessageController implements Controller {

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // load all posted parameters to local variables
        String username_receiver = request.getParameter("receiver");
        String messagecontent = request.getParameter("message");

        if (username_receiver == null) {
            throw new Exception("recipient not found");
        }
        
        // validation
        if (messagecontent == null) {
            throw new Exception("messagecontent required");
        }
        
        HttpSession session = request.getSession();

        String username_sender = session.getAttribute("username").toString();
        
        if (username_sender == null) {
            throw new Exception("sender required");
        }

        // check if username already exists
        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();
        
        User receiver;
        User sender;
        
        if ((receiver=dao.select(cm, username_receiver)) == null) {
            cm.close();
            throw new Exception("receiver not found");
        }
        
        if ((sender=dao.select(cm, username_sender)) == null) {
            cm.close();
            throw new Exception("sender not found");
        }
        
        Long id_sender = sender.getIduser();
        Long id_receiver = receiver.getIduser();
        
        // insert user to database
        Message message = new Message();
        message.setSender_iduser(id_sender);
        message.setReceiver_iduser(id_receiver);
        message.setMessage(messagecontent);
        
        
        MessageDao messagedao = new MessageDaoImpl();                        
        messagedao.insert(cm, message);
        
        // free resources
        cm.close();        
    }
}
