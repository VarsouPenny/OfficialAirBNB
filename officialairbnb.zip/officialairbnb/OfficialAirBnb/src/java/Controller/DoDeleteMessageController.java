/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.BenefitDao;
import dao.BenefitDaoImpl;
import dao.LocationDao;
import dao.LocationDaoImpl;
import dao.MessageDao;
import dao.MessageDaoImpl;
import dao.RuleDao;
import dao.RuleDaoImpl;
import dao.SpaceDao;
import dao.SpaceDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.Benefit;
import entities.House;
import entities.Location;
import entities.Message;
import entities.Rule;
import entities.Space;
import entities.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class DoDeleteMessageController implements Controller {

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // load all posted parameters to local variables
        Long idmessage = Long.parseLong(request.getParameter("idmessage"));

        if (idmessage == null) {
            throw new Exception("invalid token");
        }

        ConnectionManager cm = new ConnectionManager();
        MessageDao messagedao = new MessageDaoImpl();

        messagedao.delete(cm, idmessage);

        // free resources
        cm.close();
    }
}
