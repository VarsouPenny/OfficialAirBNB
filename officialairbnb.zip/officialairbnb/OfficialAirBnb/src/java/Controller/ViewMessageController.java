/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.BenefitDao;
import dao.BenefitDaoImpl;
import dao.HouseDao;
import dao.HouseDaoImpl;
import dao.LocationDao;
import dao.LocationDaoImpl;
import dao.MessageDao;
import dao.MessageDaoImpl;
import dao.RuleDao;
import dao.RuleDaoImpl;
import dao.SpaceDao;
import dao.SpaceDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.Benefit;
import entities.House;
import entities.Location;
import entities.Message;
import entities.Rule;
import entities.Space;
import entities.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rosa
 */
public class ViewMessageController implements LoaderController {

    @Override
    public void prepare(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Long idmessage = Long.parseLong(request.getParameter("idmessage"));

        ConnectionManager cm = new ConnectionManager();
        UserDao daousr = new UserDaoImpl();
        MessageDao dao = new MessageDaoImpl();
        
        Message msg = dao.select(cm, idmessage);
        
        if (msg == null) {
            throw new Exception("invalid token");
        } else {          
            User receiver = daousr.select(cm, msg.getReceiver_iduser());            
            User sender = daousr.select(cm, msg.getSender_iduser());            
            
            String who_receiver = receiver.getLastname() + " " + receiver.getFirstname() + " (" + receiver.getUsername() + ")";
            String who_sender = sender.getLastname() + " " + sender.getFirstname() + " (" + sender.getUsername() + ")";
            
            request.setAttribute("sender", sender);
            request.setAttribute("receiver", receiver);
            request.setAttribute("who_receiver", who_receiver);
            request.setAttribute("who_sender", who_sender);
            request.setAttribute("msg", msg);
        }
    }

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
