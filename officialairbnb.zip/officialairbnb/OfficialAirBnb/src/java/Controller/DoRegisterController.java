/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rosa
 */
public class DoRegisterController implements Controller {

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // load all posted parameters to local variables
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String password2 = request.getParameter("password2");
        String photo = request.getParameter("photo");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String email = request.getParameter("email");
        String phonenumber = request.getParameter("phonenumber");
        String housekeeper = request.getParameter("housekeeper");
        String tenant = request.getParameter("tenant");

        if (photo == null) {
            photo = "batman.jpg";
        }
        
        // validation
        if (username == null || username.length() < 3) {
            throw new Exception("username must be at least 3 letters long");
        }
//        if (password != password2){
//            throw new Exception("Passwords are different! Please be careful!");
//        }
        
        // check if username already exists
        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();
        
        if (dao.select(cm, username) != null) {
            cm.close();
            throw new Exception("username exists");
        }
        
        // insert user to database
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setFirstname(firstname);
        user.setLastname(lastname);
        user.setEmail(email);
        user.setPhoto(photo);
        user.setPhonenumber(phonenumber);
        user.setTenant(tenant != null && tenant.equals("true"));
        user.setHousekeeper(housekeeper != null && housekeeper.equals("true"));
        user.setAdministrator(false);
        
        dao.insert(cm, user);
        
        // free resources
        cm.close();        
    }
}
