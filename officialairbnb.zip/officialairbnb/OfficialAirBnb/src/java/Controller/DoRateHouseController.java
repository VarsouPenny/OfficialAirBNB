/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.HouseDao;
import dao.HouseDaoImpl;
import dao.TenantreserveshouseDao;
import dao.TenantreserveshouseDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.House;
import entities.User;
import entities.Tenantreserveshouse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class DoRateHouseController implements Controller {

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // load all posted parameters to local variables
        HttpSession session = request.getSession();

        String username_rater = session.getAttribute("username").toString();
        String form_house_idhouse = request.getParameter("idhouse");
        String form_rate = request.getParameter("rate");
        
        if (username_rater == null) {
            throw new Exception("invalid token");
        }

        if (form_house_idhouse == null) {
            throw new Exception("invalid date");
        }

        if (form_rate == null) {
            throw new Exception("invalid date");
        }
        
        
        
        // check if username already exists
        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();

        User rater = dao.select(cm, username_rater);

        Long id = rater.getIduser();
        Long idhouse = Long.parseLong(form_house_idhouse);
        int rate = Integer.parseInt(form_rate);

        TenantreserveshouseDao trddao = new TenantreserveshouseDaoImpl();
        HouseDao housedao = new HouseDaoImpl();
        
        trddao.rate(cm, id, idhouse, rate);
        housedao.rate(cm, idhouse, rate);
        
        
        // free resources
        cm.close();
    }
}
