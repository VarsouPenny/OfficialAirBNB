/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class DoLoginController implements Controller {

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // load all posted parameters to local variables
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // validation username
        if (username == null /* || username.length() < 3 */) {
            throw new Exception("username must be at least 3 letters long");
        }
        
        // validation password
        if (password == null) {
            throw new Exception("password is missing");
        }
        
        // check if username exists
        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();
        
        User user = dao.select(cm, username);
        if (user != null) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                HttpSession session = request.getSession(true);
                session.setAttribute("firstname", user.getFirstname());
                session.setAttribute("lastname", user.getLastname());
                session.setAttribute("username", user.getUsername());                
                session.setAttribute("administrator", user.getAdministrator());                
                session.setAttribute("tenant", user.getTenant());                
                session.setAttribute("housekeeper", user.getHousekeeper());                
            } else {
                cm.close();
                throw new Exception("authentication failed");
            }
        } else {
            cm.close();
            throw new Exception("username exists");
        }
    }
}
