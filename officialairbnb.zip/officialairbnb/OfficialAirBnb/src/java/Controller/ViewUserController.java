/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class ViewUserController implements LoaderController{

    @Override
    public void prepare(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String username = request.getParameter("username").toString();

        ConnectionManager cm = new ConnectionManager();
        UserDao dao = new UserDaoImpl();

        User user = dao.select(cm, username);

        int stars = dao.getStars(cm, username);
        
        
        if (user == null) {
            throw new Exception("invalid token");
        } else {
            request.setAttribute("user", user);
            request.setAttribute("stars", stars);
        }
    }

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
