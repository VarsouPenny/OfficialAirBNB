/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.BenefitDao;
import dao.BenefitDaoImpl;
import dao.HouseDao;
import dao.HouseDaoImpl;
import dao.LocationDao;
import dao.LocationDaoImpl;
import dao.RuleDao;
import dao.RuleDaoImpl;
import dao.SpaceDao;
import dao.SpaceDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.Benefit;
import entities.House;
import entities.Location;
import entities.Rule;
import entities.Space;
import entities.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rosa
 */
public class ViewHouseController implements LoaderController {

    @Override
    public void prepare(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Long idhouse = Long.parseLong(request.getParameter("idhouse"));

        ConnectionManager cm = new ConnectionManager();
        HouseDao dao = new HouseDaoImpl();
        UserDao daousr = new UserDaoImpl();

        House house = dao.select(cm, idhouse);

        if (house == null) {
            throw new Exception("invalid token");
        } else {
            User housekeeper = daousr.select(cm, house.getHousekeeper_id());
            String callname = housekeeper.getFirstname() + " " + housekeeper.getLastname();
            request.setAttribute("housekeeper_username", housekeeper.getUsername());
            request.setAttribute("housekeeper_callname", callname);

            SpaceDao sd = new SpaceDaoImpl();
            LocationDao ld = new LocationDaoImpl();
            RuleDao rd = new RuleDaoImpl();
            BenefitDao bd = new BenefitDaoImpl();

            Space space = sd.select(cm, idhouse);
            Location location = ld.select(cm, idhouse);
            Rule rule = rd.select(cm, idhouse);
            Benefit benefit = bd.select(cm, idhouse);

            request.setAttribute("house", house);
            request.setAttribute("space", space);
            request.setAttribute("location", location);
            request.setAttribute("benefit", benefit);
            request.setAttribute("rule", rule);
        }
    }

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
