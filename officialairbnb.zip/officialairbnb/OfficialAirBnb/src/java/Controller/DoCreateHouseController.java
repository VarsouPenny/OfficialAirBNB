/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.BenefitDao;
import dao.BenefitDaoImpl;
import dao.HouseDao;
import dao.HouseDaoImpl;
import dao.LocationDao;
import dao.LocationDaoImpl;
import dao.RuleDao;
import dao.RuleDaoImpl;
import dao.SpaceDao;
import dao.SpaceDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.Benefit;
import entities.House;
import entities.Location;
import entities.Rule;
import entities.Space;
import entities.User;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rosa
 */
public class DoCreateHouseController implements Controller {

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();

        String username = session.getAttribute("username").toString();

        ConnectionManager cm = new ConnectionManager();
        
        UserDao userdao = new UserDaoImpl();

        User user = userdao.select(cm, username);

        Long housekeeper_id = user.getIduser();
        
        String form_address = request.getParameter("address");
        String form_neighborhood = request.getParameter("neighborhood");
        String form_bednum = request.getParameter("bednum");
        String form_bathroomnum = request.getParameter("bathnum");
        String form_bedroomnum = request.getParameter("bedroomnum");
        String form_dimension = request.getParameter("dimension");
        String form_floor = request.getParameter("floor");
        String form_people = request.getParameter("people");
        String form_country = request.getParameter("country");
        String form_city = request.getParameter("city");
        String form_entirehouse = request.getParameter("entirehouse");
        String form_privateroom = request.getParameter("privateroom");
        String form_photo = request.getParameter("photo");
        String form_sharedroom = request.getParameter("sharedroom");
        String form_description = request.getParameter("description");
        String form_pets = request.getParameter("pets");
        String form_smoking = request.getParameter("smoking");
        String form_party = request.getParameter("party");
        String form_minimumdays = request.getParameter("minimumdays");
        String form_extraperperson = request.getParameter("extraperperson");
        String form_priceperday = request.getParameter("priceperday");
        String form_fromdate = request.getParameter("fromdate");
        String form_todate = request.getParameter("todate");
        String form_wifi = request.getParameter("wifi");
        String form_aircondition = request.getParameter("aircondition");
        String form_heating = request.getParameter("heating");
        String form_tv = request.getParameter("tv");
        String form_parking = request.getParameter("parking");
        String form_elevator = request.getParameter("elevator");
        String form_kitchen = request.getParameter("kitchen");
        String form_transport = request.getParameter("transportation");
        String form_livingroom = request.getParameter("livingroom");

        Long bedroomnum = null; // space
        Long bathroomnum = null;
        Long bednum = null;
        Long dimension = null;
        Long floor = null;
        Long people = null;

        Boolean entirehouse = null;
        Boolean privateroom = null;
        Boolean sharedroom = null;

        Long description = null;

        Boolean pets = null;
        Boolean smoking = null;
        Boolean party = null;

        Long minimumdays = null;
        Long extraperperson = null;
        Long priceperday = null;
        Date fromdate = null;
        Date todate = null;

        Boolean wifi = null;
        Boolean aircondition = null;
        Boolean heating = null;
        Boolean tv = null;
        Boolean parking = null;
        Boolean elevator = null;
        Boolean kitchen = null;
        Boolean transport = null;
        Boolean livingroom = null;

        try {
            if (form_bedroomnum != null && form_bedroomnum.trim().length() > 0) {
                bedroomnum = Long.parseLong(form_bedroomnum);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bedroomnum");
        }

        try {
            if (form_bathroomnum != null && form_bathroomnum.trim().length() > 0) {
                bathroomnum = Long.parseLong(form_bathroomnum);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bathroomnum");
        }

        try {
            if (form_bednum != null && form_bednum.trim().length() > 0) {
                bednum = Long.parseLong(form_bednum);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bednum");
        }

        try {
            if (form_dimension != null && form_dimension.trim().length() > 0) {
                dimension = Long.parseLong(form_dimension);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bednum");
        }

        try {
            if (form_floor != null && form_floor.trim().length() > 0) {
                floor = Long.parseLong(form_floor);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bednum");
        }

        try {
            if (form_people != null && form_people.trim().length() > 0) {
                people = Long.parseLong(form_people);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bednum");
        }

        try {
            if (form_minimumdays != null && form_minimumdays.trim().length() > 0) {
                minimumdays = Long.parseLong(form_minimumdays);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bednum");
        }

        try {
            if (form_extraperperson != null && form_extraperperson.trim().length() > 0) {
                extraperperson = Long.parseLong(form_extraperperson);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bednum");
        }

        try {
            if (form_priceperday != null && form_priceperday.trim().length() > 0) {
                priceperday = Long.parseLong(form_priceperday);
            }
        } catch (NumberFormatException ex) {
            throw new Exception("invalid bednum");
        }
        
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        try {
            fromdate = format.parse(form_fromdate);
        } catch (ParseException ex) {
            throw new Exception("invalid date format for from date");
        }
        
        try {
            todate = format.parse(form_todate);
        } catch (ParseException ex) {
            throw new Exception("invalid date format for to date");
        }

        if (form_entirehouse != null) {
            entirehouse = true;
        }
        if (form_privateroom != null) {
            privateroom = true;
        }
        if (form_sharedroom != null) {
            sharedroom = true;
        }
        if (form_pets != null) {
            pets = true;
        }
        if (form_smoking != null) {
            smoking = true;
        }
        if (form_party != null) {
            party = true;
        }
        if (form_wifi != null) {
            wifi = true;
        }
        if (form_aircondition != null) {
            aircondition = true;
        }
        if (form_heating != null) {
            heating = true;
        }
        if (form_tv != null) {
            tv = true;
        }
        if (form_parking != null) {
            parking = true;
        }
        if (form_elevator != null) {
            elevator = true;
        }
        if (form_kitchen != null) {
            kitchen = true;
        }
        if (form_transport != null) {
            transport = true;
        }
        if (form_livingroom != null) {
            livingroom = true;
        }

        // check if username exists
        

        HouseDao housedao = new HouseDaoImpl();
        House house = new House();
        house.setCity(form_city);
        house.setCountry(form_country);
        house.setDescription(form_description);
        house.setFloor(floor);
        house.setFromdate(fromdate);
        house.setTodate(todate);
        house.setHousekeeper_id(housekeeper_id);
        house.setNumofcritisism(0L);
        house.setPeople(people);
        house.setPhoto(form_photo);
        house.setPriceperday(priceperday);
        house.setStars(0L);
        housedao.insert(cm, house);
        

        SpaceDao dao = new SpaceDaoImpl();
        Space space = new Space();
        space.setHouse_idhouse(house.getIdhouse());
        space.setBathnum(bathroomnum);
        space.setBednum(bednum);
        space.setBedroomnum(bedroomnum);
        space.setDimension(dimension);
        space.setLivingroom(livingroom);
        space.setPrivateroom(privateroom);
        space.setPublicroom(sharedroom);
        space.setWholehouse(entirehouse);
        

        BenefitDao daobenefit = new BenefitDaoImpl();
        Benefit benefit = new Benefit();
        benefit.setHouse_idhouse(house.getIdhouse());
        benefit.setAircondition(aircondition);
        benefit.setElevator(elevator);
        benefit.setHeating(heating);
        benefit.setKitchen(kitchen);
        benefit.setParking(parking);
        benefit.setTv(tv);
        benefit.setWifi(wifi);

        
        RuleDao daorule = new RuleDaoImpl();
        Rule rule = new Rule();
        rule.setHouse_idhouse(house.getIdhouse());
        rule.setExtraperperson(extraperperson);
        rule.setMinimumdays(minimumdays);
        rule.setParty(party);
        rule.setPets(pets);
        rule.setSmoking(smoking);
        

        LocationDao daolocation = new LocationDaoImpl();
        Location location = new Location();
        location.setHouse_idhouse(house.getIdhouse());
        location.setAddress(form_address);
        location.setNeighborhood(form_neighborhood);
        location.setTransport(transport);

        
        
        dao.insert(cm, space);
        daobenefit.insert(cm, benefit);
        daorule.insert(cm, rule);
        daolocation.insert(cm, location);

        cm.close();
    }
}
