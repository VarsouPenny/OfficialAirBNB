/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.HouseDao;
import dao.HouseDaoImpl;
import dao.TenantreserveshouseDao;
import dao.TenantreserveshouseDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import dbfactory.ConnectionManager;
import entities.House;
import entities.HouseList;
import entities.Tenantreserveshouse;
import entities.User;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sun.java2d.pipe.SpanShapeRenderer;

/**
 *
 * @author mirka
 */
public class ViewMyRentedHouses implements LoaderController {

    @Override
    public void prepare(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();

        String username = session.getAttribute("username").toString();

        ConnectionManager cm = new ConnectionManager();
        
        TenantreserveshouseDao tdao = new TenantreserveshouseDaoImpl();
        
        
        HouseDao dao = new HouseDaoImpl();

        HouseList houselist = new HouseList();
        
        List<Tenantreserveshouse> reservations = tdao.select(cm, username);
        
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        
        for (Tenantreserveshouse r : reservations) {
            House h= dao.select(cm, r.getHouse_idhouse());
            
            Date d1 = r.getFromdate();
            Date d2 = r.getTodate();
            
            String sd1 = format.format(d1);
            String sd2 = format.format(d2);
            
            h.setFromdate(sd1);
            h.setTodate(sd2);
            
            houselist.add(h);            
        }
        
        request.setAttribute("houselist", houselist);
    }

    @Override
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
