/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rosa
 */
public interface LoaderController {
    public void prepare(HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    public void apply(HttpServletRequest request, HttpServletResponse response) throws Exception;
}
