/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbfactory;

import static dbfactory.DAOUtil.setValues;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author rosa
 */
public class ConnectionManager {

    private Connection connection;

    public ConnectionManager() {
        ConnectionFactory factory = ConnectionFactory.getInstance(true);

        try {
            connection = factory.getConnection();
        } catch (Exception ex) {
            connection = null;
            System.out.println(ex);
        }
    }

    public void close() {
        try {
            connection.close();
        } catch (Exception ex) {

        }
    }

    public PreparedStatement prepareStatementForSelect(String sql, Object... values) throws SQLException {
        return DAOUtil.prepareStatement(connection, sql, false, values);
    }
    
    public PreparedStatement prepareStatementForUpdate(String sql, Object... values) throws SQLException {
        return DAOUtil.prepareStatement(connection, sql, false, values);
    }

    public PreparedStatement prepareStatementForInsert(String sql, Object... values) throws SQLException {
        return DAOUtil.prepareStatement(connection, sql, true, values);
    }

}
