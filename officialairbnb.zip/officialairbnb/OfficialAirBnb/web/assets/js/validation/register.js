function validateForm() {
    var div = document.getElementById('messages');
    var errors = 0;
    var temp;
    
    return true;
    
//    div.innerHTML = "<h3><b>Please fix the following errors: </b></h3>";

    temp = document.myForm.username.value.trim();
    if (!temp) {
        document.myForm.username.style.borderColor = "red";
        div.innerHTML += '<li> username is required </li>';
        errors++;
    } else {
        document.myForm.username.style.borderColor = "black";
    }

    temp = document.myForm.lastname.value.trim();
    if (!temp) {
        document.myForm.lastname.style.borderColor = "red";
        div.innerHTML += '<li> lastname is required </li>';
        errors++;
    } else {
        document.myForm.lastname.style.borderColor = "black";
    }
    
    var p1 = document.myForm.password;
    var p2 = document.myForm.password2;
    
    if (p1 != p2) {
        div.innerHTML += '<li> passwords do not match </li>';
        errors ++;
    }

    if (errors > 0) {
        alert("Please check your form");
        return false;
    } else {
        return true;
    }
}