function validateForm() {
    var div = document.getElementById('messages');
    var errors = 0;
    var temp;
    
//    div.innerHTML = "<h3><b>Please fix the following errors: </b></h3>";

    temp = document.myForm.username.value.trim();
    if (!temp) {
        document.myForm.username.style.borderColor = "red";
        div.innerHTML += '<li> username is required </li>';
        errors++;
    } else {
        document.myForm.username.style.borderColor = "black";
    }

    temp = document.myForm.password.value.trim();
    if (!temp) {
        document.myForm.password.style.borderColor = "red";
        div.innerHTML += '<li> password is required </li>';
        errors++;
    } else {
        document.myForm.password.style.borderColor = "black";
    }

    if (errors > 0) {
        alert("Please check your form");
        return false;
    } else {
        return true;
    }
}